﻿namespace sqldenemem
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label13 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tEMIZLIKDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hARICIKULLANIMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kAYIPLARDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kISISAYISIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tOPLAMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.digertalepgunlukBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.yagmursuyu_databaseDataSet11 = new sqldenemem.yagmursuyu_databaseDataSet11();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gUNLERDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.digertalepaylikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.diger_talep_gunlukTableAdapter = new sqldenemem.yagmursuyu_databaseDataSet11TableAdapters.diger_talep_gunlukTableAdapter();
            this.diger_talep_aylikTableAdapter = new sqldenemem.yagmursuyu_databaseDataSet11TableAdapters.diger_talep_aylikTableAdapter();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.digertalepgunlukBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.digertalepaylikBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(4, 71);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(144, 16);
            this.label13.TabIndex = 101;
            this.label13.Text = "Lütfen litre olarak giriniz";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.textBox24);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Location = new System.Drawing.Point(897, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(339, 101);
            this.panel1.TabIndex = 100;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(137, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 16);
            this.label17.TabIndex = 90;
            this.label17.Text = "4";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 73);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 16);
            this.label16.TabIndex = 61;
            this.label16.Text = "3";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(5, 40);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 16);
            this.label15.TabIndex = 60;
            this.label15.Text = "2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 16);
            this.label14.TabIndex = 59;
            this.label14.Text = "1";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(157, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 23);
            this.button3.TabIndex = 57;
            this.button3.Text = "AKTAR";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(25, 37);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "VERI GIR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(25, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 23);
            this.button2.TabIndex = 24;
            this.button2.Text = "TOPLA";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(25, 67);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 22);
            this.textBox24.TabIndex = 81;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(131, 73);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(194, 16);
            this.label12.TabIndex = 82;
            this.label12.Text = "ŞUBAT GÜN SAYISINI GİRİNİZ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(465, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 16);
            this.label5.TabIndex = 99;
            this.label5.Text = "KAYIPLAR";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(357, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 16);
            this.label4.TabIndex = 98;
            this.label4.Text = "HARICI KUL.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 16);
            this.label1.TabIndex = 95;
            this.label1.Text = "ID";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(455, 35);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 22);
            this.textBox5.TabIndex = 94;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(349, 35);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 93;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(9, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 90;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn,
            this.aYLARDataGridViewTextBoxColumn,
            this.tEMIZLIKDataGridViewTextBoxColumn,
            this.hARICIKULLANIMDataGridViewTextBoxColumn,
            this.kAYIPLARDataGridViewTextBoxColumn,
            this.kISISAYISIDataGridViewTextBoxColumn,
            this.tOPLAMDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.digertalepgunlukBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(9, 146);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1475, 98);
            this.dataGridView1.TabIndex = 104;
            // 
            // ıDDataGridViewTextBoxColumn
            // 
            this.ıDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn.Name = "ıDDataGridViewTextBoxColumn";
            this.ıDDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn
            // 
            this.aYLARDataGridViewTextBoxColumn.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn.Name = "aYLARDataGridViewTextBoxColumn";
            this.aYLARDataGridViewTextBoxColumn.Width = 125;
            // 
            // tEMIZLIKDataGridViewTextBoxColumn
            // 
            this.tEMIZLIKDataGridViewTextBoxColumn.DataPropertyName = "TEMIZLIK";
            this.tEMIZLIKDataGridViewTextBoxColumn.HeaderText = "TEMIZLIK";
            this.tEMIZLIKDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tEMIZLIKDataGridViewTextBoxColumn.Name = "tEMIZLIKDataGridViewTextBoxColumn";
            this.tEMIZLIKDataGridViewTextBoxColumn.Width = 125;
            // 
            // hARICIKULLANIMDataGridViewTextBoxColumn
            // 
            this.hARICIKULLANIMDataGridViewTextBoxColumn.DataPropertyName = "HARICI_KULLANIM";
            this.hARICIKULLANIMDataGridViewTextBoxColumn.HeaderText = "HARICI_KULLANIM";
            this.hARICIKULLANIMDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.hARICIKULLANIMDataGridViewTextBoxColumn.Name = "hARICIKULLANIMDataGridViewTextBoxColumn";
            this.hARICIKULLANIMDataGridViewTextBoxColumn.Width = 125;
            // 
            // kAYIPLARDataGridViewTextBoxColumn
            // 
            this.kAYIPLARDataGridViewTextBoxColumn.DataPropertyName = "KAYIPLAR";
            this.kAYIPLARDataGridViewTextBoxColumn.HeaderText = "KAYIPLAR";
            this.kAYIPLARDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kAYIPLARDataGridViewTextBoxColumn.Name = "kAYIPLARDataGridViewTextBoxColumn";
            this.kAYIPLARDataGridViewTextBoxColumn.Width = 125;
            // 
            // kISISAYISIDataGridViewTextBoxColumn
            // 
            this.kISISAYISIDataGridViewTextBoxColumn.DataPropertyName = "KISI_SAYISI";
            this.kISISAYISIDataGridViewTextBoxColumn.HeaderText = "KISI_SAYISI";
            this.kISISAYISIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kISISAYISIDataGridViewTextBoxColumn.Name = "kISISAYISIDataGridViewTextBoxColumn";
            this.kISISAYISIDataGridViewTextBoxColumn.Width = 125;
            // 
            // tOPLAMDataGridViewTextBoxColumn
            // 
            this.tOPLAMDataGridViewTextBoxColumn.DataPropertyName = "TOPLAM";
            this.tOPLAMDataGridViewTextBoxColumn.HeaderText = "TOPLAM";
            this.tOPLAMDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tOPLAMDataGridViewTextBoxColumn.Name = "tOPLAMDataGridViewTextBoxColumn";
            this.tOPLAMDataGridViewTextBoxColumn.Width = 125;
            // 
            // digertalepgunlukBindingSource
            // 
            this.digertalepgunlukBindingSource.DataMember = "diger_talep_gunluk";
            this.digertalepgunlukBindingSource.DataSource = this.yagmursuyu_databaseDataSet11;
            // 
            // yagmursuyu_databaseDataSet11
            // 
            this.yagmursuyu_databaseDataSet11.DataSetName = "yagmursuyu_databaseDataSet11";
            this.yagmursuyu_databaseDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn1,
            this.aYLARDataGridViewTextBoxColumn1,
            this.gUNLERDataGridViewTextBoxColumn,
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn,
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.digertalepaylikBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(7, 312);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(1340, 191);
            this.dataGridView2.TabIndex = 105;
            // 
            // ıDDataGridViewTextBoxColumn1
            // 
            this.ıDDataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn1.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn1.Name = "ıDDataGridViewTextBoxColumn1";
            this.ıDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.ıDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn1
            // 
            this.aYLARDataGridViewTextBoxColumn1.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn1.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn1.Name = "aYLARDataGridViewTextBoxColumn1";
            this.aYLARDataGridViewTextBoxColumn1.Width = 125;
            // 
            // gUNLERDataGridViewTextBoxColumn
            // 
            this.gUNLERDataGridViewTextBoxColumn.DataPropertyName = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn.HeaderText = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gUNLERDataGridViewTextBoxColumn.Name = "gUNLERDataGridViewTextBoxColumn";
            this.gUNLERDataGridViewTextBoxColumn.Width = 125;
            // 
            // dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn
            // 
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn.DataPropertyName = "DIGER_KULLANIMLARDA_TOPLAM_GUNLUK_TUKETIM";
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn.HeaderText = "DIGER_KULLANIMLARDA_TOPLAM_GUNLUK_TUKETIM";
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn.Name = "dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn";
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLIKTALEPMIKTARIDataGridViewTextBoxColumn
            // 
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.DataPropertyName = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.HeaderText = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.Name = "aYLIKTALEPMIKTARIDataGridViewTextBoxColumn";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.Width = 125;
            // 
            // digertalepaylikBindingSource
            // 
            this.digertalepaylikBindingSource.DataMember = "diger_talep_aylik";
            this.digertalepaylikBindingSource.DataSource = this.yagmursuyu_databaseDataSet11;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(561, 35);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 22);
            this.textBox6.TabIndex = 102;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(682, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 16);
            this.label6.TabIndex = 103;
            this.label6.Text = "TOPLAM";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1490, 220);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 91;
            this.button4.Text = "GERI";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(243, 35);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 92;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(132, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 16);
            this.label2.TabIndex = 96;
            this.label2.Text = "AYLAR";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(253, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 97;
            this.label3.Text = "TEMIZLIK";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(1490, 162);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 108;
            this.button6.Text = "YENİLE";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(1490, 191);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 107;
            this.button5.Text = "SİL";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Cyan;
            this.label25.Location = new System.Drawing.Point(1261, 9);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(36, 16);
            this.label25.TabIndex = 158;
            this.label25.Text = "NOT";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Cyan;
            this.label22.Location = new System.Drawing.Point(1261, 28);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(323, 16);
            this.label22.TabIndex = 157;
            this.label22.Text = "LÜTFEN TÜM VERİLERİ LİTRE CİNSİNDEN GİRİNİZ";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(667, 35);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 22);
            this.textBox7.TabIndex = 159;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(573, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 16);
            this.label7.TabIndex = 160;
            this.label7.Text = "KISI SAYISI";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(115, 35);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 161;
            // 
            // diger_talep_gunlukTableAdapter
            // 
            this.diger_talep_gunlukTableAdapter.ClearBeforeFill = true;
            // 
            // diger_talep_aylikTableAdapter
            // 
            this.diger_talep_aylikTableAdapter.ClearBeforeFill = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 127);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(339, 16);
            this.label20.TabIndex = 162;
            this.label20.Text = "AY BAZINDA ORTALAMA GÜNLÜK TÜKETİM MİKTARI";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 293);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(321, 16);
            this.label21.TabIndex = 163;
            this.label21.Text = "YIL BAZINDA ORTALAMA AYLIK TÜKETİM MİKTARI";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(1688, 571);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox1);
            this.Name = "Form4";
            this.Text = "DIGER_TALEP";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.digertalepgunlukBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.digertalepaylikBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox1;
        private yagmursuyu_databaseDataSet11 yagmursuyu_databaseDataSet11;
        private System.Windows.Forms.BindingSource digertalepgunlukBindingSource;
        private yagmursuyu_databaseDataSet11TableAdapters.diger_talep_gunlukTableAdapter diger_talep_gunlukTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tEMIZLIKDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hARICIKULLANIMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kAYIPLARDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kISISAYISIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tOPLAMDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource digertalepaylikBindingSource;
        private yagmursuyu_databaseDataSet11TableAdapters.diger_talep_aylikTableAdapter diger_talep_aylikTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn gUNLERDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLIKTALEPMIKTARIDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
    }
}