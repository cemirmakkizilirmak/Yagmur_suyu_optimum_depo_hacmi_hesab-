﻿namespace sqldenemem
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cATIALANIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aKISKATSAYISIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.arzBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.yagmursuyu_databaseDataSet13 = new sqldenemem.yagmursuyu_databaseDataSet13();
            this.arzBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.yagmursuyu_databaseDataSet3 = new sqldenemem.yagmursuyu_databaseDataSet3();
            this.arzTableAdapter = new sqldenemem.yagmursuyu_databaseDataSet3TableAdapters.arzTableAdapter();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button7 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.arzTableAdapter1 = new sqldenemem.yagmursuyu_databaseDataSet13TableAdapters.arzTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arzBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arzBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn,
            this.aYLARDataGridViewTextBoxColumn,
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn,
            this.cATIALANIDataGridViewTextBoxColumn,
            this.aKISKATSAYISIDataGridViewTextBoxColumn,
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.arzBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(572, 390);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // ıDDataGridViewTextBoxColumn
            // 
            this.ıDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn.Name = "ıDDataGridViewTextBoxColumn";
            this.ıDDataGridViewTextBoxColumn.ReadOnly = true;
            this.ıDDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn
            // 
            this.aYLARDataGridViewTextBoxColumn.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn.Name = "aYLARDataGridViewTextBoxColumn";
            this.aYLARDataGridViewTextBoxColumn.Width = 125;
            // 
            // yAGISYUKSEKLIGIDataGridViewTextBoxColumn
            // 
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn.DataPropertyName = "YAGIS_YUKSEKLIGI";
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn.HeaderText = "YAGIS_YUKSEKLIGI";
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn.Name = "yAGISYUKSEKLIGIDataGridViewTextBoxColumn";
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn.Width = 125;
            // 
            // cATIALANIDataGridViewTextBoxColumn
            // 
            this.cATIALANIDataGridViewTextBoxColumn.DataPropertyName = "CATI_ALANI";
            this.cATIALANIDataGridViewTextBoxColumn.HeaderText = "CATI_ALANI";
            this.cATIALANIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cATIALANIDataGridViewTextBoxColumn.Name = "cATIALANIDataGridViewTextBoxColumn";
            this.cATIALANIDataGridViewTextBoxColumn.Width = 125;
            // 
            // aKISKATSAYISIDataGridViewTextBoxColumn
            // 
            this.aKISKATSAYISIDataGridViewTextBoxColumn.DataPropertyName = "AKIS_KATSAYISI";
            this.aKISKATSAYISIDataGridViewTextBoxColumn.HeaderText = "AKIS_KATSAYISI";
            this.aKISKATSAYISIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aKISKATSAYISIDataGridViewTextBoxColumn.Name = "aKISKATSAYISIDataGridViewTextBoxColumn";
            this.aKISKATSAYISIDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLIKARZMIKTARIDataGridViewTextBoxColumn
            // 
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn.DataPropertyName = "AYLIK_ARZ_MIKTARI";
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn.HeaderText = "AYLIK_ARZ_MIKTARI";
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn.Name = "aYLIKARZMIKTARIDataGridViewTextBoxColumn";
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn.Width = 125;
            // 
            // arzBindingSource1
            // 
            this.arzBindingSource1.DataMember = "arz";
            this.arzBindingSource1.DataSource = this.yagmursuyu_databaseDataSet13;
            // 
            // yagmursuyu_databaseDataSet13
            // 
            this.yagmursuyu_databaseDataSet13.DataSetName = "yagmursuyu_databaseDataSet13";
            this.yagmursuyu_databaseDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // arzBindingSource
            // 
            this.arzBindingSource.DataMember = "arz";
            this.arzBindingSource.DataSource = this.yagmursuyu_databaseDataSet3;
            // 
            // yagmursuyu_databaseDataSet3
            // 
            this.yagmursuyu_databaseDataSet3.DataSetName = "yagmursuyu_databaseDataSet3";
            this.yagmursuyu_databaseDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // arzTableAdapter
            // 
            this.arzTableAdapter.ClearBeforeFill = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(607, 12);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(160, 16);
            this.label17.TabIndex = 100;
            this.label17.Text = "YAGIS_YUKSEKLIGI(MM)";
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(610, 351);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(100, 22);
            this.textBox49.TabIndex = 99;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(610, 323);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(100, 22);
            this.textBox50.TabIndex = 98;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(610, 295);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(100, 22);
            this.textBox51.TabIndex = 97;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(610, 267);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(100, 22);
            this.textBox52.TabIndex = 96;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(610, 237);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(100, 22);
            this.textBox53.TabIndex = 95;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(610, 209);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(100, 22);
            this.textBox54.TabIndex = 94;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(610, 180);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(100, 22);
            this.textBox55.TabIndex = 93;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(610, 149);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(100, 22);
            this.textBox56.TabIndex = 92;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(610, 121);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(100, 22);
            this.textBox57.TabIndex = 91;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(610, 93);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(100, 22);
            this.textBox58.TabIndex = 90;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(610, 66);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(100, 22);
            this.textBox59.TabIndex = 89;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(610, 38);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(100, 22);
            this.textBox60.TabIndex = 88;
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(740, 38);
            this.chart1.Name = "chart1";
            this.chart1.Size = new System.Drawing.Size(794, 380);
            this.chart1.TabIndex = 101;
            this.chart1.Text = "chart1";
            this.chart1.Click += new System.EventHandler(this.chart1_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(610, 379);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(114, 23);
            this.button7.TabIndex = 102;
            this.button7.Text = "GRAFİK ÇİZ";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(610, 408);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 23);
            this.button1.TabIndex = 103;
            this.button1.Text = "GERİ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // arzTableAdapter1
            // 
            this.arzTableAdapter1.ClearBeforeFill = true;
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(1564, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form8";
            this.Text = "YAĞIŞ_MİKTARI_ÇATI_ALANI";
            this.Load += new System.EventHandler(this.Form8_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arzBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arzBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private yagmursuyu_databaseDataSet3 yagmursuyu_databaseDataSet3;
        private System.Windows.Forms.BindingSource arzBindingSource;
        private yagmursuyu_databaseDataSet3TableAdapters.arzTableAdapter arzTableAdapter;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button1;
        private yagmursuyu_databaseDataSet13 yagmursuyu_databaseDataSet13;
        private System.Windows.Forms.BindingSource arzBindingSource1;
        private yagmursuyu_databaseDataSet13TableAdapters.arzTableAdapter arzTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yAGISYUKSEKLIGIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cATIALANIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aKISKATSAYISIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLIKARZMIKTARIDataGridViewTextBoxColumn;
    }
}