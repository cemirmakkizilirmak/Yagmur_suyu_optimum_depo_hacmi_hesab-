﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sqldenemem
{
    public partial class Form3 : Form
    {
        SqlConnection baglanti11 = new SqlConnection("Data Source=CEMIRMAK;Initial Catalog=yagmursuyu_database;Integrated Security=True;");

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {


            VerileriYukle();
            VerileriYukle1();
            VerileriYukle();
            // ComboBox1 içeriğini temizle
            comboBox1.Items.Clear();

            // Büyük harflerle ay isimlerini ekle
            string[] aylar = { "OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN",
                       "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK" };

            comboBox1.Items.AddRange(aylar);

            // Varsayılan olarak ilk ayı seçili yap
            comboBox1.SelectedIndex = 0;

        }

        private void VerileriYukle()
        {
            try
            {
                this.mutfak_talep_gunlukTableAdapter.Fill(this.yagmursuyu_databaseDataSet10.mutfak_talep_gunluk);
                baglanti11.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM mutfak_talep_gunluk", baglanti11);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.Visible = false;
                dataGridView1.Visible = true;
                baglanti11.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri yükleme hatası: " + ex.Message);
            }
        }

        private void VerileriYukle1()
        {
            try
            {
                this.mutfak_talep_gunlukTableAdapter.Fill(this.yagmursuyu_databaseDataSet10.mutfak_talep_gunluk);
                baglanti11.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM mutfak_talep_aylik", baglanti11);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView2.DataSource = dt;
                baglanti11.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri yükleme hatası: " + ex.Message);
            }
       

        }

        private void VerileriYukle2()
        {
            try
            {
                baglanti11.Open();

                // SQL sorgusu ile iki sütunun çarpılmasını yap
                for (int ID = 1; ID <= 12; ID++)
                {
                    string sorgu = "SELECT " +
                "GUNLER, " +
                "CASE " +
                "WHEN ID = 1 THEN 'OCAK' " +
                "WHEN ID = 2 THEN 'ŞUBAT' " +
                "WHEN ID = 3 THEN 'MART' " +
                "WHEN ID = 4 THEN 'NİSAN' " +
                "WHEN ID = 5 THEN 'MAYIS' " +
                "WHEN ID = 6 THEN 'HAZİRAN' " +
                "WHEN ID = 7 THEN 'TEMMUZ' " +
                "WHEN ID = 8 THEN 'AĞUSTOS' " +
                "WHEN ID = 9 THEN 'EYLÜL' " +
                "WHEN ID = 10 THEN 'EKİM' " +
                "WHEN ID = 11 THEN 'KASIM' " +
                "WHEN ID = 12 THEN 'ARALIK' " +
                "ELSE 'BİLİNMEYEN' " +
                "END AS AYLAR, " +
                "ID, " +
                "MUTFAKLARDA_GUNLUK_TOPLAM_TUKETIM, " +
                "(GUNLER * MUTFAKLARDA_GUNLUK_TOPLAM_TUKETIM) AS AYLIK_TALEP_MIKTARI " +
                "FROM mutfak_talep_aylik " +
                "WHERE ID BETWEEN 1 AND 12 " +
                "ORDER BY ID";

                    using (SqlDataAdapter da = new SqlDataAdapter(sorgu, baglanti11))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        // Aylık talep miktarını hesapla ve DataTable'a ekle
                        foreach (DataRow row in dt.Rows)
                        {
                            // GUNLER ve TUVALETLER_ICIN_GUNLUK_TOPLAM_TUKETIM_MIKTARI'yi al
                            double gunler = Convert.ToDouble(row["GUNLER"]);
                            double tuketimMiktari = Convert.ToDouble(row["MUTFAKLARDA_GUNLUK_TOPLAM_TUKETIM"]);

                            // Aylık talep miktarını hesapla
                            double aylikTalepMiktari = gunler * tuketimMiktari;

                            // Aylık talep miktarını DataTable'a ekle
                            row["AYLIK_TALEP_MIKTARI"] = aylikTalepMiktari;
                        }

                        // DataGridView'e veri aktar
                        dataGridView2.DataSource = dt;
                    }
                    baglanti11.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri yükleme hatası: " + ex.Message);
            }
        }


        private void button4_Click(object sender, EventArgs e)
        {


            Form2 form2 = new Form2();
            form2.Show(); // Form1'i aç
            this.Hide(); // Form2'yi kapat




        }

        

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                baglanti11.Open();

                int id = Convert.ToInt32(textBox1.Text); // ID textbox'ı
                string secilenAy = comboBox1.SelectedItem?.ToString()?.ToUpper();

                if (string.IsNullOrEmpty(secilenAy))
                {
                    MessageBox.Show("Lütfen bir ay seçin!");
                    baglanti11.Close();
                    return;
                }

                // Önce ID ve AYLAR eşleşiyor mu kontrol edelim
                SqlCommand kontrolCmd = new SqlCommand("SELECT COUNT(*) FROM mutfak_talep_aylik WHERE ID = @id AND UPPER(AYLAR) = @ay", baglanti11);
                kontrolCmd.Parameters.AddWithValue("@id", id);
                kontrolCmd.Parameters.AddWithValue("@ay", secilenAy);

                int kayitSayisi = (int)kontrolCmd.ExecuteScalar();

                if (kayitSayisi == 0)
                {
                    MessageBox.Show($"ID '{id}' ile AY '{secilenAy}' eşleşmiyor. Güncelleme yapılmadı.");
                    baglanti11.Close();
                    return;
                }

                // Güncelleme işlemi (eşleşme varsa)
                SqlCommand cmd = new SqlCommand("UPDATE mutfak_talep_gunluk SET " +
                                                "MUTFAK_MUSLUGU = @l1, " +
                                                "ICME = @l2, " +
                                                "MUTFAK_DIGER = @l3, " +
                                                "KISI_SAYISI = @l4, " +
                                                "TOPLAM = @l5 " +
                                                "WHERE ID = @l6 AND UPPER(AYLAR) = @l7", baglanti11);

                cmd.Parameters.AddWithValue("@l1", Convert.ToDouble(textBox2.Text));
                cmd.Parameters.AddWithValue("@l2", Convert.ToDouble(textBox3.Text));
                cmd.Parameters.AddWithValue("@l3", Convert.ToDouble(textBox4.Text));
                cmd.Parameters.AddWithValue("@l4", Convert.ToInt32(textBox5.Text));
                cmd.Parameters.AddWithValue("@l5", Convert.ToDouble(textBox6.Text));
                cmd.Parameters.AddWithValue("@l6", id);
                cmd.Parameters.AddWithValue("@l7", secilenAy);

                cmd.ExecuteNonQuery();

                baglanti11.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lütfen geçerli bir sayı girin\nHata: " + ex.Message);
                baglanti11.Close();
            }

            VerileriYukle();

        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            // textBox2'den 8'e kadar olan değerleri topla
            double toplam = 0;
            for (int i = 2; i <= 4; i++)
            {
                // TextBox'lardan gelen değerleri sayıya dönüştür ve topla
                if (double.TryParse(this.Controls["textBox" + i].Text, out double sayi))
                {
                    toplam += sayi;
                }
                else
                {
                    // Eğer dönüşüm başarısızsa bir hata mesajı göster
                    MessageBox.Show("Lütfen geçerli bir sayı girin.");
                    return;
                }
            }

                 toplam = toplam * Convert.ToDouble(textBox5.Text);
                double sonuc = toplam;
               textBox6.Text = sonuc.ToString(); // Sonucu textBox11'e ata
            
         
        }

        private void button3_Click(object sender, EventArgs e)
        {

            try
            {
                if (baglanti11.State == ConnectionState.Closed)
                    baglanti11.Open();

                int id = Convert.ToInt32(textBox1.Text);
                string secilenAy = comboBox1.SelectedItem?.ToString()?.ToUpper();

                if (string.IsNullOrEmpty(secilenAy))
                {
                    MessageBox.Show("Lütfen bir ay seçin!");
                    return;
                }

                double tuketimMiktari;
                if (!double.TryParse(textBox6.Text, out tuketimMiktari))
                {
                    MessageBox.Show("Lütfen geçerli bir sayı girin!");
                    return;
                }

                int secilenAyNo = comboBox1.SelectedIndex + 1;
                int yil = DateTime.Now.Year;
                int gunler;

                if (secilenAyNo == 2) // ŞUBAT ise
                {
                    if (!int.TryParse(textBox24.Text, out gunler) || gunler <= 0 || gunler > 29)
                    {
                        MessageBox.Show("Lütfen Şubat ayı için geçerli bir gün sayısı girin (1-29 arası)!");
                        return;
                    }
                }
                else
                {
                    // Diğer aylar için gün sayısı otomatik
                    Dictionary<int, int> ayGunleri = new Dictionary<int, int>
        {
            { 1, 31 }, { 3, 31 }, { 4, 30 }, { 5, 31 }, { 6, 30 },
            { 7, 31 }, { 8, 31 }, { 9, 30 }, { 10, 31 }, { 11, 30 }, { 12, 31 }
        };

                    gunler = ayGunleri.ContainsKey(secilenAyNo) ? ayGunleri[secilenAyNo] : 30; // Varsayılan: 30
                }

                double aylikTalepMiktari = tuketimMiktari * gunler;

                // Kayıt gerçekten var mı kontrolü
                SqlCommand kontrolCmd = new SqlCommand("SELECT COUNT(*) FROM mutfak_talep_aylik WHERE ID = @id AND UPPER(AYLAR) = @ay", baglanti11);
                kontrolCmd.Parameters.AddWithValue("@id", id);
                kontrolCmd.Parameters.AddWithValue("@ay", secilenAy);

                int sayi = (int)kontrolCmd.ExecuteScalar();
                if (sayi == 0)
                {
                    MessageBox.Show($"ID '{id}' ile AY '{secilenAy}' eşleşmiyor. Güncelleme yapılmadı.");
                    return;
                }

                // Güncelleme işlemi
                SqlCommand cmd1 = new SqlCommand("UPDATE mutfak_talep_aylik SET " +
                    "MUTFAKLARDA_GUNLUK_TOPLAM_TUKETIM = @p3, " +
                    "AYLIK_TALEP_MIKTARI = @p6, " +
                    "GUNLER = @p8 " +
                    "WHERE ID = @p5 AND UPPER(AYLAR) = @p7", baglanti11);

                cmd1.Parameters.AddWithValue("@p3", tuketimMiktari);
                cmd1.Parameters.AddWithValue("@p6", aylikTalepMiktari);
                cmd1.Parameters.AddWithValue("@p5", id);
                cmd1.Parameters.AddWithValue("@p7", secilenAy);
                cmd1.Parameters.AddWithValue("@p8", gunler);

                int etkilenen = cmd1.ExecuteNonQuery();

                if (etkilenen > 0)
                    MessageBox.Show("Güncelleme başarılı.");
                else
                    MessageBox.Show("Güncelleme başarısız. Kayıt bulunamadı.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                if (baglanti11.State == ConnectionState.Open)
                    baglanti11.Close();
            }

            // Verileri tekrar yükle ve ekranı yenile
            VerileriYukle();
            // Verileri tekrar yükle ve ekranı yenile
            VerileriYukle1(); // dataGridView2'yi güncelle
            VerileriYukle();  // dataGridView1'i güncelle
            VerileriYukle2();
            TEMIZLE();// 
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show(); // Form1'i aç
            this.Hide(); // Form2'yi kapat
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti11.Open();
                SqlCommand cmd1 = new SqlCommand("delete from mutfak_talep_gunluk where ID=@k11", baglanti11);

                cmd1.Parameters.AddWithValue("@k1", Convert.ToDouble(textBox2.Text));
                cmd1.Parameters.AddWithValue("@k2", Convert.ToDouble(textBox3.Text));
                cmd1.Parameters.AddWithValue("@k3", Convert.ToDouble(textBox4.Text));
                cmd1.Parameters.AddWithValue("@k4", Convert.ToDouble(textBox5.Text));
                cmd1.Parameters.AddWithValue("@k5", Convert.ToDouble(textBox6.Text));
                cmd1.Parameters.AddWithValue("@k11", Convert.ToDouble(textBox1.Text));
                cmd1.ExecuteNonQuery();
                baglanti11.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Lütfen geçerli bir sayı girin. Hata: " + ex.Message);
            }
            finally
            {
                if (baglanti11.State == ConnectionState.Open)
                {
                    baglanti11.Close();
                }
            }
            VerileriYukle();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            VerileriYukle();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti11.Open();
                SqlCommand cmd1 = new SqlCommand("delete from mutfak_talep_gunluk", baglanti11);
                cmd1.ExecuteNonQuery();
                baglanti11.Close();
                baglanti11.Open();
                SqlCommand cmd2 = new SqlCommand("delete from mutfak_talep_aylik", baglanti11);
                cmd1.ExecuteNonQuery();
                baglanti11.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Lütfen geçerli bir sayı girin. Hata: " + ex.Message);
            }
            finally
            {
                if (baglanti11.State == ConnectionState.Open)
                {
                    baglanti11.Close();
                }
            }
            VerileriYukle();
        }

        private void TEMIZLE ()
        {

            for (int i = 1; i <= 6; i++)
            {
                Control ctrl = this.Controls["textBox" + i];
                if (ctrl is TextBox)
                {
                    ((TextBox)ctrl).Clear();
                }
            }

        }
    }
}
