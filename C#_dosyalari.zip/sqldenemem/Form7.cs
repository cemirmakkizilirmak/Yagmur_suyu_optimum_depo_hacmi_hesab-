﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sqldenemem
{
    public partial class Form7 : Form
    {
        SqlConnection baglanti11 = new SqlConnection("Data Source=CEMIRMAK;Initial Catalog=yagmursuyu_database;Integrated Security=True;");

        public Form7()
        {
            InitializeComponent();
        }

        private void VerileriYukle()
        {
            try
            {
                this.peyzaj_talep_katsayisiTableAdapter.Fill(this.yagmursuyu_databaseDataSet6.peyzaj_talep_katsayisi);
                baglanti11.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM peyzaj_talep_katsayisi", baglanti11);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.Visible = false;
                dataGridView1.Visible = true;
                baglanti11.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri yükleme hatası: " + ex.Message);
            }
        }

        private void VerileriYukle2()
        {
            try
            {
                this.peyjaz_talep_aylikTableAdapter.Fill(this.yagmursuyu_databaseDataSet6.peyjaz_talep_aylik);
                baglanti11.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM peyjaz_talep_aylik", baglanti11);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.Visible = false;
                dataGridView1.Visible = true;
                baglanti11.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri yükleme hatası: " + ex.Message);
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show(); // Form1'i aç
            this.Hide(); // Form2'yi kapat
        }

        private void Form7_Load(object sender, EventArgs e)
        {

            VerileriYukle();
            // ComboBox1 içeriğini temizle
            comboBox1.Items.Clear();

            // Büyük harflerle ay isimlerini ekle
            string[] aylar = { "OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN",
                       "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK" };

            comboBox1.Items.AddRange(aylar);

            // Varsayılan olarak ilk ayı seçili yap
            comboBox1.SelectedIndex = 0;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double carpim = 1;
                for (int i = 7; i <= 9; i++)
                {
                    System.Windows.Forms.TextBox txtBox = this.Controls["textBox" + i] as System.Windows.Forms.TextBox;
                    if (txtBox != null && double.TryParse(txtBox.Text, out double deger))
                    {
                        carpim *= deger;
                    }
                    else
                    {
                        MessageBox.Show($"Lütfen textBox{i} için geçerli bir sayı girin!");
                        return;
                    }
                }

                textBox10.Text = carpim.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı kontrol et ve sadece açıksa aç
                if (baglanti11.State == ConnectionState.Closed)
                {
                    baglanti11.Open();
                }

                double peyzaj_talep_kat;

                // ID girişini kontrol et
                if (!int.TryParse(textBox2.Text, out int id))
                {
                    MessageBox.Show("Lütfen geçerli bir ID girin!");
                    return;
                }

         
                // Aylık talep miktarını hesapla
                peyzaj_talep_kat = Convert.ToDouble(textBox7.Text) * Convert.ToDouble(textBox8.Text) *
                            Convert.ToDouble(textBox9.Text);
                textBox10.Text = peyzaj_talep_kat.ToString();
                textBox4.Text=textBox10.Text;

                using (SqlCommand cmd1 = new SqlCommand("UPDATE peyzaj_talep_katsayisi SET " +
                    "KS = @p1, " +
                    "KD = @p2, " +
                    "KMC = @p3, " +
                    "KL = @p4 " +
                    "WHERE ID = @p6", baglanti11))
                {
                    cmd1.Parameters.AddWithValue("@p1", Convert.ToDouble(textBox7.Text));  
                    cmd1.Parameters.AddWithValue("@p2", Convert.ToDouble(textBox8.Text)); 
                    cmd1.Parameters.AddWithValue("@p3", Convert.ToDouble(textBox9.Text)); 
                    cmd1.Parameters.AddWithValue("@p4", Convert.ToDouble(textBox10.Text)); 
                    cmd1.Parameters.AddWithValue("@p6", id); 
              

                    // SQL komutunu çalıştır
                    int rowsAffected = cmd1.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Güncelleme başarılı!");
                    }
                    else
                    {
                        MessageBox.Show("Güncelleme başarısız!");
                    }
                }
            }
            catch (Exception ex)
            {
                // Hata durumunda hata mesajını göster
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                if (baglanti11.State == ConnectionState.Open)
                    baglanti11.Close();
            }

            // Verileri tekrar yükle ve ekranı yenile
            VerileriYukle();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                double carpim = 1;
                for (int i = 3; i <= 5; i++)
                {
                    System.Windows.Forms.TextBox txtBox = this.Controls["textBox" + i] as System.Windows.Forms.TextBox;
                    if (txtBox != null && double.TryParse(txtBox.Text, out double deger))
                    {
                        carpim *= deger;
                    }
                    else
                    {
                        MessageBox.Show($"Lütfen textBox{i} için geçerli bir sayı girin!");
                        return;
                    }
                }

                carpim = carpim / 1000;
                textBox6.Text = carpim.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
               try
            {
                // Bağlantıyı kontrol et ve sadece açıksa aç
                if (baglanti11.State == ConnectionState.Closed)
                {
                    baglanti11.Open();
                }

                double aylik_peyzaj;

                // ID girişini kontrol et
                if (!int.TryParse(textBox1.Text, out int id))
                {
                    MessageBox.Show("Lütfen geçerli bir ID girin!");
                    return;
                }

                // ComboBox1'den seçilen ayın büyük harfli halini al
                string secilenAy = comboBox1.SelectedItem?.ToString().ToUpper();
                if (string.IsNullOrEmpty(secilenAy))
                {
                    MessageBox.Show("Lütfen bir ay seçin!");
                    return;
                }

                // Aylık talep miktarını hesapla
                aylik_peyzaj = Convert.ToDouble(textBox3.Text) * Convert.ToDouble(textBox4.Text) *
                            Convert.ToDouble(textBox5.Text);
                textBox6.Text = aylik_peyzaj.ToString();

                using (SqlCommand cmd1 = new SqlCommand("UPDATE peyjaz_talep_aylik SET " +
                    "AYLIK_BUHARLASMA = @p2, " +
                    "BITKI_SU_KULLANIM_KATSAYISI = @p3, " +
                    "SULANACAK_ALAN = @p4, " +
                    "TOPLAM_AYLIK_TALEP = @p5 " +
                    "WHERE ID = @p6 AND UPPER(AYLAR) = @p7", baglanti11))
                {
         
                    cmd1.Parameters.AddWithValue("@p2", Convert.ToDouble(textBox3.Text)); // Çatı alanı
                    cmd1.Parameters.AddWithValue("@p3", Convert.ToDouble(textBox4.Text)); // Güvenlik faktörü
                    cmd1.Parameters.AddWithValue("@p4", Convert.ToDouble(textBox5.Text)); // Havza katsayısı
                    cmd1.Parameters.AddWithValue("@p5", aylik_peyzaj); // Aylık arz miktarı
                    cmd1.Parameters.AddWithValue("@p6", id); // ID değeri
                    cmd1.Parameters.AddWithValue("@p7", secilenAy); // Büyük harfli ay ismi

                    // SQL komutunu çalıştır
                    int rowsAffected = cmd1.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Güncelleme başarılı!");
                    }
                    else
                    {
                        MessageBox.Show("Güncelleme başarısız! ID veya ay ismi yanlış olabilir.");
                    }
                }
            }
            catch (Exception ex)
            {
                // Hata durumunda hata mesajını göster
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                if (baglanti11.State == ConnectionState.Open)
                    baglanti11.Close();
            }

            // Verileri tekrar yükle ve ekranı yenile
            VerileriYukle2();
        }
    }
}
