﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sqldenemem
{
    
    public partial class Form1 : Form
    {


        SqlConnection baglanti = new SqlConnection("Data Source=CEMIRMAK;Initial Catalog=yagmursuyu_database;Integrated Security=True;");

     
        public Form1()
        {
           
            InitializeComponent();
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
        

            VerileriYukle();
            VerileriYukle1();

            // ComboBox1 içeriğini temizle
            comboBox1.Items.Clear();

            // Büyük harflerle ay isimlerini ekle
            string[] aylar = { "OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN",
                       "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK" };

            comboBox1.Items.AddRange(aylar);

            // Varsayılan olarak ilk ayı seçili yap
            comboBox1.SelectedIndex = 0;
        }

        private void VerileriYukle()
        {
            try
            {
                this.tuvalet_talep_gunlukTableAdapter.Fill(this.yagmursuyu_databaseDataSet12.tuvalet_talep_gunluk);
                baglanti.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM tuvalet_talep_gunluk", baglanti);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                baglanti.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri yükleme hatası: " + ex.Message);
            }
        }

        private void VerileriYukle1()
        {
            try
            {
                this.tuvalet_talep_aylikTableAdapter.Fill(this.yagmursuyu_databaseDataSet12.tuvalet_talep_aylik);
                baglanti.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM tuvalet_talep_aylik", baglanti);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView2.DataSource = dt;
                baglanti.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri yükleme hatası: " + ex.Message);
            }
        }

        private void VerileriYukle2()
        {
            try
            {
                baglanti.Open();

                // SQL sorgusu ile iki sütunun çarpılmasını yap
                for (int ID = 1; ID <= 12; ID++)
                {
                    string sorgu = "SELECT " +
                "GUNLER, " +
                "CASE " +
                "WHEN ID = 1 THEN 'OCAK' " +
                "WHEN ID = 2 THEN 'ŞUBAT' " +
                "WHEN ID = 3 THEN 'MART' " +
                "WHEN ID = 4 THEN 'NİSAN' " +
                "WHEN ID = 5 THEN 'MAYIS' " +
                "WHEN ID = 6 THEN 'HAZİRAN' " +
                "WHEN ID = 7 THEN 'TEMMUZ' " +
                "WHEN ID = 8 THEN 'AĞUSTOS' " +
                "WHEN ID = 9 THEN 'EYLÜL' " +
                "WHEN ID = 10 THEN 'EKİM' " +
                "WHEN ID = 11 THEN 'KASIM' " +
                "WHEN ID = 12 THEN 'ARALIK' " +
                "ELSE 'BİLİNMEYEN' " +
                "END AS AYLAR, " +
                "ID, " +
                "TUVALETLER_ICIN_GUNLUK_TOPLAM_TUKETIM_MIKTARI, " +
                "(GUNLER * TUVALETLER_ICIN_GUNLUK_TOPLAM_TUKETIM_MIKTARI) AS AYLIK_TALEP_MIKTARI " +
                "FROM tuvalet_talep_aylik " +
                "WHERE ID BETWEEN 1 AND 12 " +
                "ORDER BY ID";

                    using (SqlDataAdapter da = new SqlDataAdapter(sorgu, baglanti))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        // Aylık talep miktarını hesapla ve DataTable'a ekle
                        foreach (DataRow row in dt.Rows)
                        {
                            // GUNLER ve TUVALETLER_ICIN_GUNLUK_TOPLAM_TUKETIM_MIKTARI'yi al
                            double gunler = Convert.ToDouble(row["GUNLER"]);
                            double tuketimMiktari = Convert.ToDouble(row["TUVALETLER_ICIN_GUNLUK_TOPLAM_TUKETIM_MIKTARI"]);

                            // Aylık talep miktarını hesapla
                            double aylikTalepMiktari = gunler * tuketimMiktari;

                            // Aylık talep miktarını DataTable'a ekle
                            row["AYLIK_TALEP_MIKTARI"] = aylikTalepMiktari;
                        }

                        // DataGridView'e veri aktar
                        dataGridView2.DataSource = dt;
                    }
                    baglanti.Close();
                }
               }

            catch (Exception ex)
            {
                MessageBox.Show("Veri yükleme hatası: " + ex.Message);
            }
        }

        private void TEMIZLE ()
        {
            for (int i = 2; i <= 11; i++)
            {
                Control ctrl = this.Controls["textBox" + i];
                if (ctrl is TextBox)
                {
                    ((TextBox)ctrl).Clear();
                }
            }



        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                baglanti.Open();

                int id = Convert.ToInt32(textBox1.Text); // ID textbox'ı
                string secilenAy = comboBox1.SelectedItem?.ToString()?.ToUpper();

                if (string.IsNullOrEmpty(secilenAy))
                {
                    MessageBox.Show("Lütfen bir ay seçin!");
                    baglanti.Close();
                    return;
                }

                // Önce ID ve AYLAR eşleşiyor mu kontrol edelim
                SqlCommand kontrolCmd = new SqlCommand("SELECT COUNT(*) FROM tuvalet_talep_aylik WHERE ID = @id AND UPPER(AYLAR) = @ay", baglanti);
                kontrolCmd.Parameters.AddWithValue("@id", id);
                kontrolCmd.Parameters.AddWithValue("@ay", secilenAy);

                int kayitSayisi = (int)kontrolCmd.ExecuteScalar();

                if (kayitSayisi == 0)
                {
                    MessageBox.Show($"ID '{id}' ile AY '{secilenAy}' eşleşmiyor. Güncelleme yapılmadı.");
                    baglanti.Close();
                    return;
                }

                // Güncelleme işlemi (eşleşme varsa)
                SqlCommand cmd = new SqlCommand("UPDATE tuvalet_talep_gunluk SET " +
                                                "DUS = @l1, " +
                                                "LAVABO = @l2, " +
                                                "TUVALET = @l3, " +
                                                "CAMASIR_MAKINESI = @l4, " +
                                                "KUVET = @l5, " +
                                                "DIS_YIKAMA = @l6, " +
                                                "CAMASIR_MUSLUGU = @l7, " +
                                                "BANYO_DIGER = @l8, " +
                                                "KISI_SAYISI = @l9, " +
                                                "TOPLAM = @l10 " +
                                                "WHERE ID = @l11 AND UPPER(AYLAR) = @l12", baglanti);

                cmd.Parameters.AddWithValue("@l1", Convert.ToDouble(textBox2.Text));
                cmd.Parameters.AddWithValue("@l2", Convert.ToDouble(textBox3.Text));
                cmd.Parameters.AddWithValue("@l3", Convert.ToDouble(textBox4.Text));
                cmd.Parameters.AddWithValue("@l4", Convert.ToDouble(textBox5.Text));
                cmd.Parameters.AddWithValue("@l5", Convert.ToDouble(textBox6.Text));
                cmd.Parameters.AddWithValue("@l6", Convert.ToDouble(textBox7.Text));
                cmd.Parameters.AddWithValue("@l7", Convert.ToDouble(textBox8.Text));
                cmd.Parameters.AddWithValue("@l8", Convert.ToDouble(textBox9.Text));
                cmd.Parameters.AddWithValue("@l9", Convert.ToInt32(textBox10.Text));
                cmd.Parameters.AddWithValue("@l10", Convert.ToDouble(textBox11.Text));
                cmd.Parameters.AddWithValue("@l11", id);
                cmd.Parameters.AddWithValue("@l12", secilenAy);

                cmd.ExecuteNonQuery();

                baglanti.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lütfen geçerli bir sayı girin\nHata: " + ex.Message);
                baglanti.Close();
            }


            VerileriYukle();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // textBox2 den 8 e kadar olan değerleri topla
            double toplam = 0;
            for (int i = 2; i <= 9; i++)
            {
                // TextBox lardan gelen değerleri sayıya dönüştür ve topla
                if (double.TryParse(this.Controls["textBox" + i].Text, out double sayi))
                {
                    toplam += sayi;
                }
                else
                {
                    // Eğer dönüşüm başarısızsa bir hata mesajı göster
                    MessageBox.Show("Lütfen geçerli bir sayı girin.");
                    return;
                }
            }

            // textBox10 daki değeri al ve toplama çarp
            if (double.TryParse(textBox10.Text, out double faktor))
            {
                double sonuc = toplam * faktor;
                textBox11.Text = sonuc.ToString(); // Sonucu textBox11'e ata
            }
            else
            {
                // Eğer textBox10 daki değer geçerli bir sayı değilse
                MessageBox.Show("Lütfen geçerli bir sayı girin.");

                return;
            }


        }

       

    private void button4_Click(object sender, EventArgs e)
        {

           
               Form2 form2 = new Form2();
               form2.Show(); // Form1'i aç
               this.Hide(); // Form2'yi kapat

            


        }

        private void button7_Click(object sender, EventArgs e)
        {
      
            VerileriYukle();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti.Open();
                SqlCommand cmd1 = new SqlCommand("delete from tuvalet_talep_gunluk WHERE ID=@K11",baglanti);

                cmd1.Parameters.AddWithValue("@k1", Convert.ToDouble(textBox2.Text));
                cmd1.Parameters.AddWithValue("@k2", Convert.ToDouble(textBox3.Text));
                cmd1.Parameters.AddWithValue("@k3", Convert.ToDouble(textBox4.Text));
                cmd1.Parameters.AddWithValue("@k4", Convert.ToDouble(textBox5.Text));
                cmd1.Parameters.AddWithValue("@k5", Convert.ToDouble(textBox6.Text));
                cmd1.Parameters.AddWithValue("@k11", Convert.ToInt32(textBox1.Text));

                cmd1.ExecuteNonQuery();
                baglanti.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Lütfen geçerli bir sayı girin. Hata: " + ex.Message);
            }
            finally
            {
                if (baglanti.State == ConnectionState.Open)
                {
                    baglanti.Close();
                }
            }
            VerileriYukle();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti.Open();
                SqlCommand cmd2 = new SqlCommand("delete from tuvalet_talep_gunluk", baglanti);
                cmd2.ExecuteNonQuery();
                baglanti.Close();
            }
            catch { MessageBox.Show("veriler silinemedi"); }
        }


        private void button3_Click_1(object sender, EventArgs e)
        {

            try
            {
                if (baglanti.State == ConnectionState.Closed)
                    baglanti.Open();

                int id = Convert.ToInt32(textBox1.Text);
                string secilenAy = comboBox1.SelectedItem?.ToString()?.ToUpper();

                if (string.IsNullOrEmpty(secilenAy))
                {
                    MessageBox.Show("Lütfen bir ay seçin!");
                    return;
                }

                double tuketimMiktari;
                if (!double.TryParse(textBox11.Text, out tuketimMiktari))
                {
                    MessageBox.Show("Lütfen geçerli bir sayı girin!");
                    return;
                }

                int secilenAyNo = comboBox1.SelectedIndex + 1;
                int yil = DateTime.Now.Year;
                int gunler;

                if (secilenAyNo == 2) // ŞUBAT ise
                {
                    if (!int.TryParse(textBox24.Text, out gunler) || gunler <= 0 || gunler > 29)
                    {
                        MessageBox.Show("Lütfen Şubat ayı için geçerli bir gün sayısı girin (1-29 arası)!");
                        return;
                    }
                }
                else
                {
                    // Diğer aylar için gün sayısı otomatik
                    Dictionary<int, int> ayGunleri = new Dictionary<int, int>
        {
            { 1, 31 }, { 3, 31 }, { 4, 30 }, { 5, 31 }, { 6, 30 },
            { 7, 31 }, { 8, 31 }, { 9, 30 }, { 10, 31 }, { 11, 30 }, { 12, 31 }
        };

                    gunler = ayGunleri.ContainsKey(secilenAyNo) ? ayGunleri[secilenAyNo] : 30; // Varsayılan: 30
                }

                double aylikTalepMiktari = tuketimMiktari * gunler;

                // Kayıt gerçekten var mı kontrolü
                SqlCommand kontrolCmd = new SqlCommand("SELECT COUNT(*) FROM tuvalet_talep_aylik WHERE ID = @id AND UPPER(AYLAR) = @ay", baglanti);
                kontrolCmd.Parameters.AddWithValue("@id", id);
                kontrolCmd.Parameters.AddWithValue("@ay", secilenAy);

                int sayi = (int)kontrolCmd.ExecuteScalar();
                if (sayi == 0)
                {
                    MessageBox.Show($"ID '{id}' ile AY '{secilenAy}' eşleşmiyor. Güncelleme yapılmadı.");
                    return;
                }

                // Güncelleme işlemi
                SqlCommand cmd1 = new SqlCommand("UPDATE tuvalet_talep_aylik SET " +
                    "TUVALETLER_ICIN_GUNLUK_TOPLAM_TUKETIM_MIKTARI = @p3, " +
                    "AYLIK_TALEP_MIKTARI = @p6, " +
                    "GUNLER = @p8 " +
                    "WHERE ID = @p5 AND UPPER(AYLAR) = @p7", baglanti);

                cmd1.Parameters.AddWithValue("@p3", tuketimMiktari);
                cmd1.Parameters.AddWithValue("@p6", aylikTalepMiktari);
                cmd1.Parameters.AddWithValue("@p5", id);
                cmd1.Parameters.AddWithValue("@p7", secilenAy);
                cmd1.Parameters.AddWithValue("@p8", gunler);

                int etkilenen = cmd1.ExecuteNonQuery();

                if (etkilenen > 0)
                    MessageBox.Show("Güncelleme başarılı.");
                else
                    MessageBox.Show("Güncelleme başarısız. Kayıt bulunamadı.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                if (baglanti.State == ConnectionState.Open)
                    baglanti.Close();
            }

            // Verileri tekrar yükle ve ekranı yenile
            VerileriYukle1(); // dataGridView2'yi güncelle
            VerileriYukle();  // dataGridView1'i güncelle
            VerileriYukle2();
            TEMIZLE();// textboxların içini temizler


        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            for (int i = 2; i <= 11; i++)
            {
                Control ctrl = this.Controls["textBox" + i];
                if (ctrl is TextBox)
                {
                    ((TextBox)ctrl).Clear();
                }
            }

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

    }
}
