﻿namespace sqldenemem
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gUNLERDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tuvalettalepaylikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.yagmursuyu_databaseDataSet2 = new sqldenemem.yagmursuyu_databaseDataSet2();
            this.tuvalet_talep_aylikTableAdapter = new sqldenemem.yagmursuyu_databaseDataSet2TableAdapters.tuvalet_talep_aylikTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gUNLERDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mutfaktalepaylikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ben = new sqldenemem.ben();
            this.mutfak_talep_aylikTableAdapter = new sqldenemem.benTableAdapters.mutfak_talep_aylikTableAdapter();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gUNLERDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.digertalepaylikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.yagmursuyu_databaseDataSet = new sqldenemem.yagmursuyu_databaseDataSet();
            this.diger_talep_aylikTableAdapter = new sqldenemem.yagmursuyu_databaseDataSetTableAdapters.diger_talep_aylikTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cATIALANIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aKISKATSAYISIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.arzBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.yagmursuyu_databaseDataSet13 = new sqldenemem.yagmursuyu_databaseDataSet13();
            this.arzBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.yagmursuyu_databaseDataSet3 = new sqldenemem.yagmursuyu_databaseDataSet3();
            this.arzTableAdapter = new sqldenemem.yagmursuyu_databaseDataSet3TableAdapters.arzTableAdapter();
            this.button6 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLIKBUHARLASMADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bITKISUKULLANIMKATSAYISIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sULANACAKALANDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tOPLAMAYLIKTALEPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.peyjaztalepaylikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.yagmursuyu_databaseDataSet6 = new sqldenemem.yagmursuyu_databaseDataSet6();
            this.peyjaz_talep_aylikTableAdapter = new sqldenemem.yagmursuyu_databaseDataSet6TableAdapters.peyjaz_talep_aylikTableAdapter();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.textBox98 = new System.Windows.Forms.TextBox();
            this.textBox99 = new System.Windows.Forms.TextBox();
            this.textBox100 = new System.Windows.Forms.TextBox();
            this.textBox101 = new System.Windows.Forms.TextBox();
            this.textBox102 = new System.Windows.Forms.TextBox();
            this.textBox103 = new System.Windows.Forms.TextBox();
            this.textBox104 = new System.Windows.Forms.TextBox();
            this.textBox105 = new System.Windows.Forms.TextBox();
            this.textBox106 = new System.Windows.Forms.TextBox();
            this.textBox107 = new System.Windows.Forms.TextBox();
            this.textBox108 = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.textBox110 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox111 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.arzTableAdapter1 = new sqldenemem.yagmursuyu_databaseDataSet13TableAdapters.arzTableAdapter();
            this.label28 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tuvalettalepaylikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mutfaktalepaylikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ben)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.digertalepaylikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arzBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arzBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.peyjaztalepaylikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn,
            this.aYLARDataGridViewTextBoxColumn,
            this.gUNLERDataGridViewTextBoxColumn,
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn,
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tuvalettalepaylikBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(1220, 390);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(345, 175);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // ıDDataGridViewTextBoxColumn
            // 
            this.ıDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn.Name = "ıDDataGridViewTextBoxColumn";
            this.ıDDataGridViewTextBoxColumn.ReadOnly = true;
            this.ıDDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn
            // 
            this.aYLARDataGridViewTextBoxColumn.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn.Name = "aYLARDataGridViewTextBoxColumn";
            this.aYLARDataGridViewTextBoxColumn.Width = 125;
            // 
            // gUNLERDataGridViewTextBoxColumn
            // 
            this.gUNLERDataGridViewTextBoxColumn.DataPropertyName = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn.HeaderText = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gUNLERDataGridViewTextBoxColumn.Name = "gUNLERDataGridViewTextBoxColumn";
            this.gUNLERDataGridViewTextBoxColumn.Width = 125;
            // 
            // tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn
            // 
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn.DataPropertyName = "TUVALETLER_ICIN_GUNLUK_TOPLAM_TUKETIM_MIKTARI";
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn.HeaderText = "TUVALETLER_ICIN_GUNLUK_TOPLAM_TUKETIM_MIKTARI";
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn.Name = "tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn";
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLIKTALEPMIKTARIDataGridViewTextBoxColumn
            // 
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.DataPropertyName = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.HeaderText = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.Name = "aYLIKTALEPMIKTARIDataGridViewTextBoxColumn";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.Width = 125;
            // 
            // tuvalettalepaylikBindingSource
            // 
            this.tuvalettalepaylikBindingSource.DataMember = "tuvalet_talep_aylik";
            this.tuvalettalepaylikBindingSource.DataSource = this.yagmursuyu_databaseDataSet2;
            // 
            // yagmursuyu_databaseDataSet2
            // 
            this.yagmursuyu_databaseDataSet2.DataSetName = "yagmursuyu_databaseDataSet2";
            this.yagmursuyu_databaseDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tuvalet_talep_aylikTableAdapter
            // 
            this.tuvalet_talep_aylikTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn1,
            this.aYLARDataGridViewTextBoxColumn1,
            this.gUNLERDataGridViewTextBoxColumn1,
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn,
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.mutfaktalepaylikBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(869, 390);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(345, 175);
            this.dataGridView2.TabIndex = 4;
            this.dataGridView2.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellDoubleClick);
            // 
            // ıDDataGridViewTextBoxColumn1
            // 
            this.ıDDataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn1.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn1.Name = "ıDDataGridViewTextBoxColumn1";
            this.ıDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.ıDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn1
            // 
            this.aYLARDataGridViewTextBoxColumn1.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn1.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn1.Name = "aYLARDataGridViewTextBoxColumn1";
            this.aYLARDataGridViewTextBoxColumn1.Width = 125;
            // 
            // gUNLERDataGridViewTextBoxColumn1
            // 
            this.gUNLERDataGridViewTextBoxColumn1.DataPropertyName = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn1.HeaderText = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.gUNLERDataGridViewTextBoxColumn1.Name = "gUNLERDataGridViewTextBoxColumn1";
            this.gUNLERDataGridViewTextBoxColumn1.Width = 125;
            // 
            // mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn
            // 
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn.DataPropertyName = "MUTFAKLARDA_GUNLUK_TOPLAM_TUKETIM";
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn.HeaderText = "MUTFAKLARDA_GUNLUK_TOPLAM_TUKETIM";
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn.Name = "mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn";
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLIKTALEPMIKTARIDataGridViewTextBoxColumn1
            // 
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn1.DataPropertyName = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn1.HeaderText = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn1.Name = "aYLIKTALEPMIKTARIDataGridViewTextBoxColumn1";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn1.Width = 125;
            // 
            // mutfaktalepaylikBindingSource
            // 
            this.mutfaktalepaylikBindingSource.DataMember = "mutfak_talep_aylik";
            this.mutfaktalepaylikBindingSource.DataSource = this.ben;
            // 
            // ben
            // 
            this.ben.DataSetName = "ben";
            this.ben.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mutfak_talep_aylikTableAdapter
            // 
            this.mutfak_talep_aylikTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn2,
            this.aYLARDataGridViewTextBoxColumn2,
            this.gUNLERDataGridViewTextBoxColumn2,
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn,
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn2});
            this.dataGridView3.DataSource = this.digertalepaylikBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(1571, 390);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(345, 175);
            this.dataGridView3.TabIndex = 5;
            this.dataGridView3.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellDoubleClick);
            // 
            // ıDDataGridViewTextBoxColumn2
            // 
            this.ıDDataGridViewTextBoxColumn2.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn2.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn2.Name = "ıDDataGridViewTextBoxColumn2";
            this.ıDDataGridViewTextBoxColumn2.ReadOnly = true;
            this.ıDDataGridViewTextBoxColumn2.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn2
            // 
            this.aYLARDataGridViewTextBoxColumn2.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn2.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn2.Name = "aYLARDataGridViewTextBoxColumn2";
            this.aYLARDataGridViewTextBoxColumn2.Width = 125;
            // 
            // gUNLERDataGridViewTextBoxColumn2
            // 
            this.gUNLERDataGridViewTextBoxColumn2.DataPropertyName = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn2.HeaderText = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.gUNLERDataGridViewTextBoxColumn2.Name = "gUNLERDataGridViewTextBoxColumn2";
            this.gUNLERDataGridViewTextBoxColumn2.Width = 125;
            // 
            // dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn
            // 
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn.DataPropertyName = "DIGER_KULLANIMLARDA_TOPLAM_GUNLUK_TUKETIM";
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn.HeaderText = "DIGER_KULLANIMLARDA_TOPLAM_GUNLUK_TUKETIM";
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn.Name = "dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn";
            this.dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLIKTALEPMIKTARIDataGridViewTextBoxColumn2
            // 
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn2.DataPropertyName = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn2.HeaderText = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn2.Name = "aYLIKTALEPMIKTARIDataGridViewTextBoxColumn2";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn2.Width = 125;
            // 
            // digertalepaylikBindingSource
            // 
            this.digertalepaylikBindingSource.DataMember = "diger_talep_aylik";
            this.digertalepaylikBindingSource.DataSource = this.yagmursuyu_databaseDataSet;
            // 
            // yagmursuyu_databaseDataSet
            // 
            this.yagmursuyu_databaseDataSet.DataSetName = "yagmursuyu_databaseDataSet";
            this.yagmursuyu_databaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // diger_talep_aylikTableAdapter
            // 
            this.diger_talep_aylikTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1317, 574);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "TUVALET_TALEP";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(986, 571);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(156, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "MUTFAK_TALEP";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1668, 571);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(128, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "DIGER_TALEP";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "OCAK";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "ŞUBAT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "MART";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "NİSAN";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "MAYIS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "HAZİRAN";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 206);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "TEMMUZ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 234);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 16);
            this.label8.TabIndex = 13;
            this.label8.Text = "AĞUSTOS";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 261);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 16);
            this.label9.TabIndex = 14;
            this.label9.Text = "EYLÜL";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 292);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 16);
            this.label10.TabIndex = 15;
            this.label10.Text = "EKİM";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(11, 320);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 16);
            this.label11.TabIndex = 16;
            this.label11.Text = "KASIM";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 347);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 16);
            this.label12.TabIndex = 17;
            this.label12.Text = "ARALIK";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(83, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 18;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(83, 63);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 19;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(83, 90);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 20;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(83, 118);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 21;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(83, 146);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 22);
            this.textBox5.TabIndex = 22;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(83, 177);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 22);
            this.textBox6.TabIndex = 23;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(83, 206);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 22);
            this.textBox7.TabIndex = 24;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(83, 234);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 22);
            this.textBox8.TabIndex = 25;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(83, 264);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 22);
            this.textBox9.TabIndex = 26;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(83, 292);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 22);
            this.textBox10.TabIndex = 27;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(83, 320);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 22);
            this.textBox11.TabIndex = 28;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(83, 348);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 22);
            this.textBox12.TabIndex = 29;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(211, 348);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 22);
            this.textBox13.TabIndex = 41;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(211, 320);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 22);
            this.textBox14.TabIndex = 40;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(211, 292);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 22);
            this.textBox15.TabIndex = 39;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(211, 264);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 22);
            this.textBox16.TabIndex = 38;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(211, 234);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 22);
            this.textBox17.TabIndex = 37;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(211, 206);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 22);
            this.textBox18.TabIndex = 36;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(211, 177);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 22);
            this.textBox19.TabIndex = 35;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(211, 146);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 22);
            this.textBox20.TabIndex = 34;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(211, 118);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 22);
            this.textBox21.TabIndex = 33;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(211, 90);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 22);
            this.textBox22.TabIndex = 32;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(211, 63);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(100, 22);
            this.textBox23.TabIndex = 31;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(211, 35);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 22);
            this.textBox24.TabIndex = 30;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(341, 348);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(100, 22);
            this.textBox25.TabIndex = 53;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(341, 320);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(100, 22);
            this.textBox26.TabIndex = 52;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(341, 292);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 22);
            this.textBox27.TabIndex = 51;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(341, 264);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 22);
            this.textBox28.TabIndex = 50;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(341, 234);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(100, 22);
            this.textBox29.TabIndex = 49;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(341, 206);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(100, 22);
            this.textBox30.TabIndex = 48;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(341, 177);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(100, 22);
            this.textBox31.TabIndex = 47;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(341, 146);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(100, 22);
            this.textBox32.TabIndex = 46;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(341, 118);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(100, 22);
            this.textBox33.TabIndex = 45;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(341, 90);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(100, 22);
            this.textBox34.TabIndex = 44;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(341, 63);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(100, 22);
            this.textBox35.TabIndex = 43;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(341, 35);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(100, 22);
            this.textBox36.TabIndex = 42;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(592, 348);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(100, 22);
            this.textBox37.TabIndex = 65;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(592, 320);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(100, 22);
            this.textBox38.TabIndex = 64;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(592, 292);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(100, 22);
            this.textBox39.TabIndex = 63;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(592, 264);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(100, 22);
            this.textBox40.TabIndex = 62;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(592, 234);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(100, 22);
            this.textBox41.TabIndex = 61;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(592, 206);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(100, 22);
            this.textBox42.TabIndex = 60;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(592, 177);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(100, 22);
            this.textBox43.TabIndex = 59;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(592, 146);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(100, 22);
            this.textBox44.TabIndex = 58;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(592, 118);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(100, 22);
            this.textBox45.TabIndex = 57;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(592, 90);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(100, 22);
            this.textBox46.TabIndex = 56;
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(592, 63);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(100, 22);
            this.textBox47.TabIndex = 55;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(592, 35);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(100, 22);
            this.textBox48.TabIndex = 54;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1614, 657);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(191, 23);
            this.button4.TabIndex = 66;
            this.button4.Text = "TALEPLERİ TOPLA";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.TOP);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(1614, 686);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(191, 23);
            this.button5.TabIndex = 67;
            this.button5.Text = "GERİ";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn3,
            this.aYLARDataGridViewTextBoxColumn3,
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn,
            this.cATIALANIDataGridViewTextBoxColumn,
            this.aKISKATSAYISIDataGridViewTextBoxColumn,
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.arzBindingSource1;
            this.dataGridView4.Location = new System.Drawing.Point(869, 615);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.RowTemplate.Height = 24;
            this.dataGridView4.Size = new System.Drawing.Size(345, 175);
            this.dataGridView4.TabIndex = 69;
            this.dataGridView4.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellContentClick);
            this.dataGridView4.DoubleClick += new System.EventHandler(this.dataGridView4_DoubleClick);
            // 
            // ıDDataGridViewTextBoxColumn3
            // 
            this.ıDDataGridViewTextBoxColumn3.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn3.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn3.Name = "ıDDataGridViewTextBoxColumn3";
            this.ıDDataGridViewTextBoxColumn3.ReadOnly = true;
            this.ıDDataGridViewTextBoxColumn3.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn3
            // 
            this.aYLARDataGridViewTextBoxColumn3.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn3.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn3.Name = "aYLARDataGridViewTextBoxColumn3";
            this.aYLARDataGridViewTextBoxColumn3.Width = 125;
            // 
            // yAGISYUKSEKLIGIDataGridViewTextBoxColumn
            // 
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn.DataPropertyName = "YAGIS_YUKSEKLIGI";
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn.HeaderText = "YAGIS_YUKSEKLIGI";
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn.Name = "yAGISYUKSEKLIGIDataGridViewTextBoxColumn";
            this.yAGISYUKSEKLIGIDataGridViewTextBoxColumn.Width = 125;
            // 
            // cATIALANIDataGridViewTextBoxColumn
            // 
            this.cATIALANIDataGridViewTextBoxColumn.DataPropertyName = "CATI_ALANI";
            this.cATIALANIDataGridViewTextBoxColumn.HeaderText = "CATI_ALANI";
            this.cATIALANIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cATIALANIDataGridViewTextBoxColumn.Name = "cATIALANIDataGridViewTextBoxColumn";
            this.cATIALANIDataGridViewTextBoxColumn.Width = 125;
            // 
            // aKISKATSAYISIDataGridViewTextBoxColumn
            // 
            this.aKISKATSAYISIDataGridViewTextBoxColumn.DataPropertyName = "AKIS_KATSAYISI";
            this.aKISKATSAYISIDataGridViewTextBoxColumn.HeaderText = "AKIS_KATSAYISI";
            this.aKISKATSAYISIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aKISKATSAYISIDataGridViewTextBoxColumn.Name = "aKISKATSAYISIDataGridViewTextBoxColumn";
            this.aKISKATSAYISIDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLIKARZMIKTARIDataGridViewTextBoxColumn
            // 
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn.DataPropertyName = "AYLIK_ARZ_MIKTARI";
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn.HeaderText = "AYLIK_ARZ_MIKTARI";
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn.Name = "aYLIKARZMIKTARIDataGridViewTextBoxColumn";
            this.aYLIKARZMIKTARIDataGridViewTextBoxColumn.Width = 125;
            // 
            // arzBindingSource1
            // 
            this.arzBindingSource1.DataMember = "arz";
            this.arzBindingSource1.DataSource = this.yagmursuyu_databaseDataSet13;
            // 
            // yagmursuyu_databaseDataSet13
            // 
            this.yagmursuyu_databaseDataSet13.DataSetName = "yagmursuyu_databaseDataSet13";
            this.yagmursuyu_databaseDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // arzBindingSource
            // 
            this.arzBindingSource.DataMember = "arz";
            this.arzBindingSource.DataSource = this.yagmursuyu_databaseDataSet3;
            // 
            // yagmursuyu_databaseDataSet3
            // 
            this.yagmursuyu_databaseDataSet3.DataSetName = "yagmursuyu_databaseDataSet3";
            this.yagmursuyu_databaseDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // arzTableAdapter
            // 
            this.arzTableAdapter.ClearBeforeFill = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(975, 796);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(128, 23);
            this.button6.TabIndex = 70;
            this.button6.Text = "ARZ";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(44, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(139, 16);
            this.label13.TabIndex = 71;
            this.label13.Text = "TUV_BANYO_TALEP";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(205, 9);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 16);
            this.label14.TabIndex = 72;
            this.label14.Text = "MUTFAK_TALEP";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(338, 9);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(99, 16);
            this.label15.TabIndex = 73;
            this.label15.Text = "DIGER_TALEP";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(593, 9);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(108, 16);
            this.label16.TabIndex = 74;
            this.label16.Text = "TOPLAM TALEP";
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(719, 348);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(100, 22);
            this.textBox49.TabIndex = 86;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(719, 320);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(100, 22);
            this.textBox50.TabIndex = 85;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(719, 292);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(100, 22);
            this.textBox51.TabIndex = 84;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(719, 264);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(100, 22);
            this.textBox52.TabIndex = 83;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(719, 234);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(100, 22);
            this.textBox53.TabIndex = 82;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(719, 206);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(100, 22);
            this.textBox54.TabIndex = 81;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(719, 177);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(100, 22);
            this.textBox55.TabIndex = 80;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(719, 146);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(100, 22);
            this.textBox56.TabIndex = 79;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(719, 118);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(100, 22);
            this.textBox57.TabIndex = 78;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(719, 90);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(100, 22);
            this.textBox58.TabIndex = 77;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(719, 63);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(100, 22);
            this.textBox59.TabIndex = 76;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(719, 35);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(100, 22);
            this.textBox60.TabIndex = 75;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(727, 9);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(92, 16);
            this.label17.TabIndex = 87;
            this.label17.Text = "TOPLAM ARZ";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(1343, 799);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(128, 23);
            this.button8.TabIndex = 89;
            this.button8.Text = "PEYZAJ_TALEP";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // dataGridView5
            // 
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn4,
            this.aYLARDataGridViewTextBoxColumn4,
            this.aYLIKBUHARLASMADataGridViewTextBoxColumn,
            this.bITKISUKULLANIMKATSAYISIDataGridViewTextBoxColumn,
            this.sULANACAKALANDataGridViewTextBoxColumn,
            this.tOPLAMAYLIKTALEPDataGridViewTextBoxColumn});
            this.dataGridView5.DataSource = this.peyjaztalepaylikBindingSource;
            this.dataGridView5.Location = new System.Drawing.Point(1220, 615);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowHeadersWidth = 51;
            this.dataGridView5.RowTemplate.Height = 24;
            this.dataGridView5.Size = new System.Drawing.Size(335, 175);
            this.dataGridView5.TabIndex = 90;
            this.dataGridView5.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellDoubleClick);
            // 
            // ıDDataGridViewTextBoxColumn4
            // 
            this.ıDDataGridViewTextBoxColumn4.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn4.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn4.Name = "ıDDataGridViewTextBoxColumn4";
            this.ıDDataGridViewTextBoxColumn4.ReadOnly = true;
            this.ıDDataGridViewTextBoxColumn4.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn4
            // 
            this.aYLARDataGridViewTextBoxColumn4.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn4.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn4.Name = "aYLARDataGridViewTextBoxColumn4";
            this.aYLARDataGridViewTextBoxColumn4.Width = 125;
            // 
            // aYLIKBUHARLASMADataGridViewTextBoxColumn
            // 
            this.aYLIKBUHARLASMADataGridViewTextBoxColumn.DataPropertyName = "AYLIK_BUHARLASMA";
            this.aYLIKBUHARLASMADataGridViewTextBoxColumn.HeaderText = "AYLIK_BUHARLASMA";
            this.aYLIKBUHARLASMADataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLIKBUHARLASMADataGridViewTextBoxColumn.Name = "aYLIKBUHARLASMADataGridViewTextBoxColumn";
            this.aYLIKBUHARLASMADataGridViewTextBoxColumn.Width = 125;
            // 
            // bITKISUKULLANIMKATSAYISIDataGridViewTextBoxColumn
            // 
            this.bITKISUKULLANIMKATSAYISIDataGridViewTextBoxColumn.DataPropertyName = "BITKI_SU_KULLANIM_KATSAYISI";
            this.bITKISUKULLANIMKATSAYISIDataGridViewTextBoxColumn.HeaderText = "BITKI_SU_KULLANIM_KATSAYISI";
            this.bITKISUKULLANIMKATSAYISIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.bITKISUKULLANIMKATSAYISIDataGridViewTextBoxColumn.Name = "bITKISUKULLANIMKATSAYISIDataGridViewTextBoxColumn";
            this.bITKISUKULLANIMKATSAYISIDataGridViewTextBoxColumn.Width = 125;
            // 
            // sULANACAKALANDataGridViewTextBoxColumn
            // 
            this.sULANACAKALANDataGridViewTextBoxColumn.DataPropertyName = "SULANACAK_ALAN";
            this.sULANACAKALANDataGridViewTextBoxColumn.HeaderText = "SULANACAK_ALAN";
            this.sULANACAKALANDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sULANACAKALANDataGridViewTextBoxColumn.Name = "sULANACAKALANDataGridViewTextBoxColumn";
            this.sULANACAKALANDataGridViewTextBoxColumn.Width = 125;
            // 
            // tOPLAMAYLIKTALEPDataGridViewTextBoxColumn
            // 
            this.tOPLAMAYLIKTALEPDataGridViewTextBoxColumn.DataPropertyName = "TOPLAM_AYLIK_TALEP";
            this.tOPLAMAYLIKTALEPDataGridViewTextBoxColumn.HeaderText = "TOPLAM_AYLIK_TALEP";
            this.tOPLAMAYLIKTALEPDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tOPLAMAYLIKTALEPDataGridViewTextBoxColumn.Name = "tOPLAMAYLIKTALEPDataGridViewTextBoxColumn";
            this.tOPLAMAYLIKTALEPDataGridViewTextBoxColumn.Width = 125;
            // 
            // peyjaztalepaylikBindingSource
            // 
            this.peyjaztalepaylikBindingSource.DataMember = "peyjaz_talep_aylik";
            this.peyjaztalepaylikBindingSource.DataSource = this.yagmursuyu_databaseDataSet6;
            // 
            // yagmursuyu_databaseDataSet6
            // 
            this.yagmursuyu_databaseDataSet6.DataSetName = "yagmursuyu_databaseDataSet6";
            this.yagmursuyu_databaseDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // peyjaz_talep_aylikTableAdapter
            // 
            this.peyjaz_talep_aylikTableAdapter.ClearBeforeFill = true;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(465, 348);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(100, 22);
            this.textBox61.TabIndex = 102;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(465, 320);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(100, 22);
            this.textBox62.TabIndex = 101;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(465, 292);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(100, 22);
            this.textBox63.TabIndex = 100;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(465, 264);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(100, 22);
            this.textBox64.TabIndex = 99;
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(465, 234);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(100, 22);
            this.textBox65.TabIndex = 98;
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(465, 206);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(100, 22);
            this.textBox66.TabIndex = 97;
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(465, 177);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(100, 22);
            this.textBox67.TabIndex = 96;
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(465, 146);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(100, 22);
            this.textBox68.TabIndex = 95;
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(465, 118);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(100, 22);
            this.textBox69.TabIndex = 94;
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(465, 90);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(100, 22);
            this.textBox70.TabIndex = 93;
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(465, 63);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(100, 22);
            this.textBox71.TabIndex = 92;
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(465, 35);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(100, 22);
            this.textBox72.TabIndex = 91;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(462, 9);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 16);
            this.label18.TabIndex = 103;
            this.label18.Text = "PEYZAJ_TALEP";
            // 
            // chart2
            // 
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(12, 399);
            this.chart2.Name = "chart2";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "TOPLAM_TALEP";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "TOPLAM_ARZ";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Legend = "Legend1";
            series3.Name = "ARZ/TALEP_FARKI";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Legend = "Legend1";
            series4.Name = "TANKIN_İÇİNDEKİ_SU_HACMİ";
            this.chart2.Series.Add(series1);
            this.chart2.Series.Add(series2);
            this.chart2.Series.Add(series3);
            this.chart2.Series.Add(series4);
            this.chart2.Size = new System.Drawing.Size(851, 431);
            this.chart2.TabIndex = 104;
            this.chart2.Text = "chart2";
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(901, 348);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(100, 22);
            this.textBox73.TabIndex = 116;
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(901, 320);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(100, 22);
            this.textBox74.TabIndex = 115;
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(901, 292);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(100, 22);
            this.textBox75.TabIndex = 114;
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(901, 264);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(100, 22);
            this.textBox76.TabIndex = 113;
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(901, 234);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(100, 22);
            this.textBox77.TabIndex = 112;
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(901, 206);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(100, 22);
            this.textBox78.TabIndex = 111;
            // 
            // textBox79
            // 
            this.textBox79.Location = new System.Drawing.Point(901, 177);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(100, 22);
            this.textBox79.TabIndex = 110;
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(901, 146);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(100, 22);
            this.textBox80.TabIndex = 109;
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(901, 118);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(100, 22);
            this.textBox81.TabIndex = 108;
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(901, 90);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(100, 22);
            this.textBox82.TabIndex = 107;
            // 
            // textBox83
            // 
            this.textBox83.Location = new System.Drawing.Point(901, 63);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(100, 22);
            this.textBox83.TabIndex = 106;
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(901, 35);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(100, 22);
            this.textBox84.TabIndex = 105;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(885, 9);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(137, 16);
            this.label19.TabIndex = 117;
            this.label19.Text = "ARZ-TALEP MİKTARI";
            // 
            // textBox85
            // 
            this.textBox85.Location = new System.Drawing.Point(1094, 348);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(100, 22);
            this.textBox85.TabIndex = 129;
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(1094, 320);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(100, 22);
            this.textBox86.TabIndex = 128;
            // 
            // textBox87
            // 
            this.textBox87.Location = new System.Drawing.Point(1094, 292);
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(100, 22);
            this.textBox87.TabIndex = 127;
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(1094, 264);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(100, 22);
            this.textBox88.TabIndex = 126;
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(1094, 234);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(100, 22);
            this.textBox89.TabIndex = 125;
            // 
            // textBox90
            // 
            this.textBox90.Location = new System.Drawing.Point(1094, 206);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(100, 22);
            this.textBox90.TabIndex = 124;
            // 
            // textBox91
            // 
            this.textBox91.Location = new System.Drawing.Point(1094, 177);
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(100, 22);
            this.textBox91.TabIndex = 123;
            // 
            // textBox92
            // 
            this.textBox92.Location = new System.Drawing.Point(1094, 146);
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(100, 22);
            this.textBox92.TabIndex = 122;
            // 
            // textBox93
            // 
            this.textBox93.Location = new System.Drawing.Point(1094, 118);
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(100, 22);
            this.textBox93.TabIndex = 121;
            // 
            // textBox94
            // 
            this.textBox94.Location = new System.Drawing.Point(1094, 90);
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(100, 22);
            this.textBox94.TabIndex = 120;
            // 
            // textBox95
            // 
            this.textBox95.Location = new System.Drawing.Point(1094, 63);
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new System.Drawing.Size(100, 22);
            this.textBox95.TabIndex = 119;
            // 
            // textBox96
            // 
            this.textBox96.Location = new System.Drawing.Point(1094, 35);
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new System.Drawing.Size(100, 22);
            this.textBox96.TabIndex = 118;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(1061, 9);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(181, 16);
            this.label20.TabIndex = 130;
            this.label20.Text = "TANKIN İÇİNDEKİ SU HACMİ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(1314, 9);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(70, 16);
            this.label21.TabIndex = 131;
            this.label21.Text = "FAZLA SU";
            // 
            // textBox97
            // 
            this.textBox97.Location = new System.Drawing.Point(1300, 345);
            this.textBox97.Name = "textBox97";
            this.textBox97.Size = new System.Drawing.Size(100, 22);
            this.textBox97.TabIndex = 143;
            // 
            // textBox98
            // 
            this.textBox98.Location = new System.Drawing.Point(1300, 317);
            this.textBox98.Name = "textBox98";
            this.textBox98.Size = new System.Drawing.Size(100, 22);
            this.textBox98.TabIndex = 142;
            // 
            // textBox99
            // 
            this.textBox99.Location = new System.Drawing.Point(1300, 289);
            this.textBox99.Name = "textBox99";
            this.textBox99.Size = new System.Drawing.Size(100, 22);
            this.textBox99.TabIndex = 141;
            // 
            // textBox100
            // 
            this.textBox100.Location = new System.Drawing.Point(1300, 261);
            this.textBox100.Name = "textBox100";
            this.textBox100.Size = new System.Drawing.Size(100, 22);
            this.textBox100.TabIndex = 140;
            // 
            // textBox101
            // 
            this.textBox101.Location = new System.Drawing.Point(1300, 231);
            this.textBox101.Name = "textBox101";
            this.textBox101.Size = new System.Drawing.Size(100, 22);
            this.textBox101.TabIndex = 139;
            // 
            // textBox102
            // 
            this.textBox102.Location = new System.Drawing.Point(1300, 203);
            this.textBox102.Name = "textBox102";
            this.textBox102.Size = new System.Drawing.Size(100, 22);
            this.textBox102.TabIndex = 138;
            // 
            // textBox103
            // 
            this.textBox103.Location = new System.Drawing.Point(1300, 174);
            this.textBox103.Name = "textBox103";
            this.textBox103.Size = new System.Drawing.Size(100, 22);
            this.textBox103.TabIndex = 137;
            // 
            // textBox104
            // 
            this.textBox104.Location = new System.Drawing.Point(1300, 143);
            this.textBox104.Name = "textBox104";
            this.textBox104.Size = new System.Drawing.Size(100, 22);
            this.textBox104.TabIndex = 136;
            // 
            // textBox105
            // 
            this.textBox105.Location = new System.Drawing.Point(1300, 115);
            this.textBox105.Name = "textBox105";
            this.textBox105.Size = new System.Drawing.Size(100, 22);
            this.textBox105.TabIndex = 135;
            // 
            // textBox106
            // 
            this.textBox106.Location = new System.Drawing.Point(1300, 87);
            this.textBox106.Name = "textBox106";
            this.textBox106.Size = new System.Drawing.Size(100, 22);
            this.textBox106.TabIndex = 134;
            // 
            // textBox107
            // 
            this.textBox107.Location = new System.Drawing.Point(1300, 60);
            this.textBox107.Name = "textBox107";
            this.textBox107.Size = new System.Drawing.Size(100, 22);
            this.textBox107.TabIndex = 133;
            // 
            // textBox108
            // 
            this.textBox108.Location = new System.Drawing.Point(1300, 32);
            this.textBox108.Name = "textBox108";
            this.textBox108.Size = new System.Drawing.Size(100, 22);
            this.textBox108.TabIndex = 132;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(1451, 32);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(114, 42);
            this.button9.TabIndex = 144;
            this.button9.Text = "ARZ-TALEP MİKTARI";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(1451, 80);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(114, 46);
            this.button10.TabIndex = 145;
            this.button10.Text = "TANKIN İÇİNDEKİ SU HACMİ";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(1423, 132);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(200, 67);
            this.button11.TabIndex = 146;
            this.button11.Text = "DENGELEME GRAFİĞİNİ ÇİZ";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // textBox110
            // 
            this.textBox110.Location = new System.Drawing.Point(1673, 32);
            this.textBox110.Name = "textBox110";
            this.textBox110.Size = new System.Drawing.Size(100, 22);
            this.textBox110.TabIndex = 149;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(1647, 9);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(149, 16);
            this.label23.TabIndex = 150;
            this.label23.Text = "SEÇİLEN DEPO HACMİ";
            // 
            // textBox111
            // 
            this.textBox111.Location = new System.Drawing.Point(1673, 94);
            this.textBox111.Name = "textBox111";
            this.textBox111.Size = new System.Drawing.Size(100, 22);
            this.textBox111.TabIndex = 151;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(1613, 75);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(238, 16);
            this.label24.TabIndex = 152;
            this.label24.Text = "BAŞLANGIÇTA DEPODAKİ SU HACMİ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(1420, 280);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(323, 16);
            this.label22.TabIndex = 153;
            this.label22.Text = "LÜTFEN TÜM VERİLERİ LİTRE CİNSİNDEN GİRİNİZ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(1420, 261);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(36, 16);
            this.label25.TabIndex = 154;
            this.label25.Text = "NOT";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(820, 1085);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(71, 16);
            this.label33.TabIndex = 161;
            this.label33.Text = "KONTROL";
            // 
            // arzTableAdapter1
            // 
            this.arzTableAdapter1.ClearBeforeFill = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Red;
            this.label28.Location = new System.Drawing.Point(1420, 212);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(629, 16);
            this.label28.TabIndex = 165;
            this.label28.Text = "OPTİMUM DEPO HACMİNİ BULABİLMESİ İÇİN BAŞLANGIÇ VE SEÇİLEN DEPO HACMİNİ SIFIR GİR" +
    "İNİZ";
            this.label28.Click += new System.EventHandler(this.label28_Click);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(1924, 905);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.textBox111);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.textBox110);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.textBox97);
            this.Controls.Add(this.textBox98);
            this.Controls.Add(this.textBox99);
            this.Controls.Add(this.textBox100);
            this.Controls.Add(this.textBox101);
            this.Controls.Add(this.textBox102);
            this.Controls.Add(this.textBox103);
            this.Controls.Add(this.textBox104);
            this.Controls.Add(this.textBox105);
            this.Controls.Add(this.textBox106);
            this.Controls.Add(this.textBox107);
            this.Controls.Add(this.textBox108);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.textBox85);
            this.Controls.Add(this.textBox86);
            this.Controls.Add(this.textBox87);
            this.Controls.Add(this.textBox88);
            this.Controls.Add(this.textBox89);
            this.Controls.Add(this.textBox90);
            this.Controls.Add(this.textBox91);
            this.Controls.Add(this.textBox92);
            this.Controls.Add(this.textBox93);
            this.Controls.Add(this.textBox94);
            this.Controls.Add(this.textBox95);
            this.Controls.Add(this.textBox96);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textBox73);
            this.Controls.Add(this.textBox74);
            this.Controls.Add(this.textBox75);
            this.Controls.Add(this.textBox76);
            this.Controls.Add(this.textBox77);
            this.Controls.Add(this.textBox78);
            this.Controls.Add(this.textBox79);
            this.Controls.Add(this.textBox80);
            this.Controls.Add(this.textBox81);
            this.Controls.Add(this.textBox82);
            this.Controls.Add(this.textBox83);
            this.Controls.Add(this.textBox84);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.textBox61);
            this.Controls.Add(this.textBox62);
            this.Controls.Add(this.textBox63);
            this.Controls.Add(this.textBox64);
            this.Controls.Add(this.textBox65);
            this.Controls.Add(this.textBox66);
            this.Controls.Add(this.textBox67);
            this.Controls.Add(this.textBox68);
            this.Controls.Add(this.textBox69);
            this.Controls.Add(this.textBox70);
            this.Controls.Add(this.textBox71);
            this.Controls.Add(this.textBox72);
            this.Controls.Add(this.dataGridView5);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form6";
            this.Text = "ARZ_TALEP_DENGESI";
            this.Load += new System.EventHandler(this.Form6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tuvalettalepaylikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mutfaktalepaylikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ben)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.digertalepaylikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arzBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arzBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.peyjaztalepaylikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private yagmursuyu_databaseDataSet2 yagmursuyu_databaseDataSet2;
        private System.Windows.Forms.BindingSource tuvalettalepaylikBindingSource;
        private yagmursuyu_databaseDataSet2TableAdapters.tuvalet_talep_aylikTableAdapter tuvalet_talep_aylikTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gUNLERDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLIKTALEPMIKTARIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private ben ben;
        private System.Windows.Forms.BindingSource mutfaktalepaylikBindingSource;
        private benTableAdapters.mutfak_talep_aylikTableAdapter mutfak_talep_aylikTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn gUNLERDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLIKTALEPMIKTARIDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private yagmursuyu_databaseDataSet yagmursuyu_databaseDataSet;
        private System.Windows.Forms.BindingSource digertalepaylikBindingSource;
        private yagmursuyu_databaseDataSetTableAdapters.diger_talep_aylikTableAdapter diger_talep_aylikTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn gUNLERDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dIGERKULLANIMLARDATOPLAMGUNLUKTUKETIMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLIKTALEPMIKTARIDataGridViewTextBoxColumn2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dataGridView4;
        private yagmursuyu_databaseDataSet3 yagmursuyu_databaseDataSet3;
        private System.Windows.Forms.BindingSource arzBindingSource;
        private yagmursuyu_databaseDataSet3TableAdapters.arzTableAdapter arzTableAdapter;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.DataGridView dataGridView5;
        private yagmursuyu_databaseDataSet6 yagmursuyu_databaseDataSet6;
        private System.Windows.Forms.BindingSource peyjaztalepaylikBindingSource;
        private yagmursuyu_databaseDataSet6TableAdapters.peyjaz_talep_aylikTableAdapter peyjaz_talep_aylikTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLIKBUHARLASMADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bITKISUKULLANIMKATSAYISIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sULANACAKALANDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tOPLAMAYLIKTALEPDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.TextBox textBox98;
        private System.Windows.Forms.TextBox textBox99;
        private System.Windows.Forms.TextBox textBox100;
        private System.Windows.Forms.TextBox textBox101;
        private System.Windows.Forms.TextBox textBox102;
        private System.Windows.Forms.TextBox textBox103;
        private System.Windows.Forms.TextBox textBox104;
        private System.Windows.Forms.TextBox textBox105;
        private System.Windows.Forms.TextBox textBox106;
        private System.Windows.Forms.TextBox textBox107;
        private System.Windows.Forms.TextBox textBox108;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox textBox110;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox111;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label33;
        private yagmursuyu_databaseDataSet13 yagmursuyu_databaseDataSet13;
        private System.Windows.Forms.BindingSource arzBindingSource1;
        private yagmursuyu_databaseDataSet13TableAdapters.arzTableAdapter arzTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn yAGISYUKSEKLIGIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cATIALANIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aKISKATSAYISIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLIKARZMIKTARIDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label28;
    }
}