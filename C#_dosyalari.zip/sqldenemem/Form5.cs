﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sqldenemem
{
    public partial class Form5 : Form
    {
        SqlConnection baglanti11 = new SqlConnection("Data Source=CEMIRMAK;Initial Catalog=yagmursuyu_database;Integrated Security=True;");
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
           
            VerileriYukle();
            comboBox1.Items.Clear();

            string[] aylar = { "OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN",
                       "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK" };

            comboBox1.Items.AddRange(aylar);

            // Varsayılan olarak ilk ayı seçili yap
            comboBox1.SelectedIndex = 0;
        }

        private void VerileriYukle()
        {
            try
            {
                this.arzTableAdapter1.Fill(this.yagmursuyu_databaseDataSet13.arz);
                baglanti11.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM arz", baglanti11);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.Visible = false;
                dataGridView1.Visible = true;
                baglanti11.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri yükleme hatası: " + ex.Message);
            }
        }
      
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double carpim = 1;
                for (int i = 3; i <= 5; i++)
                {
                    System.Windows.Forms.TextBox txtBox = this.Controls["textBox" + i] as System.Windows.Forms.TextBox;
                    if (txtBox != null && double.TryParse(txtBox.Text, out double deger))
                    {
                        carpim *= deger;
                        
                    }
                    else
                    {
                        MessageBox.Show($"Lütfen textBox{i} için geçerli bir sayı girin!");
                        return;
                    }
                }
                //carpim = carpim / 1000;
                textBox7.Text = carpim.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        
        private void button4_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show(); // Form1'i aç
            this.Hide(); // Form2'yi kapat
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı kontrol et ve sadece açıksa aç
                if (baglanti11.State == ConnectionState.Closed)
                {
                    baglanti11.Open();
                }

                double aylik_arz;

                // ID girişini kontrol et
                if (!int.TryParse(textBox1.Text, out int id))
                {
                    MessageBox.Show("Lütfen geçerli bir ID girin!");
                    return;
                }

                // ComboBox1'den seçilen ayın büyük harfli halini al
                string secilenAy = comboBox1.SelectedItem?.ToString().ToUpper();
                if (string.IsNullOrEmpty(secilenAy))
                {
                    MessageBox.Show("Lütfen bir ay seçin!");
                    return;
                }

                // Aylık talep miktarını hesapla
                aylik_arz = Convert.ToDouble(textBox3.Text) * Convert.ToDouble(textBox4.Text) *
                            Convert.ToDouble(textBox5.Text);
                textBox7.Text = aylik_arz.ToString();

                using (SqlCommand cmd1 = new SqlCommand("UPDATE arz SET " +
                    "YAGIS_YUKSEKLIGI = @p1, " +
                    "CATI_ALANI = @p2, " +
                    "AKIS_KATSAYISI = @p3, " +
                    "AYLIK_ARZ_MIKTARI = @p5 " +
                    "WHERE ID = @p6 AND UPPER(AYLAR) = @p7", baglanti11))
                {
                    cmd1.Parameters.AddWithValue("@p1", Convert.ToDouble(textBox3.Text));  // Yağış yüksekliği
                    cmd1.Parameters.AddWithValue("@p2", Convert.ToDouble(textBox4.Text)); // Çatı alanı
                    cmd1.Parameters.AddWithValue("@p3", Convert.ToDouble(textBox5.Text)); // Güvenlik faktörü
                   // cmd1.Parameters.AddWithValue("@p4", Convert.ToDouble(textBox6.Text)); // Havza katsayısı
                    cmd1.Parameters.AddWithValue("@p5", aylik_arz); // Aylık arz miktarı
                    cmd1.Parameters.AddWithValue("@p6", id); // ID değeri
                    cmd1.Parameters.AddWithValue("@p7", secilenAy); // Büyük harfli ay ismi

                    // SQL komutunu çalıştır
                    int rowsAffected = cmd1.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Güncelleme başarılı!");
                    }
                    else
                    {
                        MessageBox.Show("Güncelleme başarısız! ID veya ay ismi yanlış olabilir.");
                    }
                }
            }
            catch (Exception ex)
            {
                // Hata durumunda hata mesajını göster
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                if (baglanti11.State == ConnectionState.Open)
                    baglanti11.Close();
            }

            // Verileri tekrar yükle ve ekranı yenile
            VerileriYukle();



        }


        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti11.Open();
                SqlCommand cmd1 = new SqlCommand("delete from arz where ID=@k11", baglanti11);

                cmd1.Parameters.AddWithValue("@k1", Convert.ToDouble(textBox3.Text));
                cmd1.Parameters.AddWithValue("@k2", Convert.ToDouble(textBox4.Text));
                cmd1.Parameters.AddWithValue("@k3", Convert.ToDouble(textBox5.Text));
              //  cmd1.Parameters.AddWithValue("@k4", Convert.ToDouble(textBox6.Text));
                cmd1.Parameters.AddWithValue("@k5", Convert.ToDouble(textBox7.Text));
                cmd1.Parameters.AddWithValue("@k11", Convert.ToInt32(textBox1.Text));
                cmd1.ExecuteNonQuery();
                baglanti11.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Lütfen geçerli bir sayı girin. Hata: " + ex.Message);
            }
            finally
            {
                if (baglanti11.State == ConnectionState.Open)
                {
                    baglanti11.Close();
                }
            }
            VerileriYukle();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
