﻿namespace sqldenemem
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label13 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mUTFAKMUSLUGUDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ıCMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mUTFAKDIGERDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kISISAYISIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tOPLAMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mutfaktalepgunlukBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.yagmursuyu_databaseDataSet10 = new sqldenemem.yagmursuyu_databaseDataSet10();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gUNLERDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mutfaktalepaylikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.yagmursuyu_databaseDataSet9 = new sqldenemem.yagmursuyu_databaseDataSet9();
            this.button4 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.mutfak_talep_aylikTableAdapter = new sqldenemem.yagmursuyu_databaseDataSet9TableAdapters.mutfak_talep_aylikTableAdapter();
            this.mutfak_talep_gunlukTableAdapter = new sqldenemem.yagmursuyu_databaseDataSet10TableAdapters.mutfak_talep_gunlukTableAdapter();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mutfaktalepgunlukBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mutfaktalepaylikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet9)).BeginInit();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 73);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(144, 16);
            this.label13.TabIndex = 84;
            this.label13.Text = "Lütfen litre olarak giriniz";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.textBox24);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Location = new System.Drawing.Point(927, 11);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(339, 101);
            this.panel1.TabIndex = 83;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(137, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 16);
            this.label17.TabIndex = 90;
            this.label17.Text = "4";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 73);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 16);
            this.label16.TabIndex = 61;
            this.label16.Text = "3";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(5, 40);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 16);
            this.label15.TabIndex = 60;
            this.label15.Text = "2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 16);
            this.label14.TabIndex = 59;
            this.label14.Text = "1";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(157, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 23);
            this.button3.TabIndex = 57;
            this.button3.Text = "AKTAR";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(25, 37);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "VERI GIR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(25, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 23);
            this.button2.TabIndex = 24;
            this.button2.Text = "TOPLA";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(25, 67);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 22);
            this.textBox24.TabIndex = 81;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(131, 73);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(194, 16);
            this.label12.TabIndex = 82;
            this.label12.Text = "ŞUBAT GÜN SAYISINI GİRİNİZ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(594, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 16);
            this.label5.TabIndex = 74;
            this.label5.Text = "KISI_SAYISI";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(477, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 16);
            this.label4.TabIndex = 73;
            this.label4.Text = "MUTFAK_DIGER";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(371, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 16);
            this.label3.TabIndex = 72;
            this.label3.Text = "ICME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(265, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 16);
            this.label2.TabIndex = 71;
            this.label2.Text = "MUT_MUS";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 16);
            this.label1.TabIndex = 70;
            this.label1.Text = "ID";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(586, 37);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 22);
            this.textBox5.TabIndex = 63;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(480, 37);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 62;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(374, 37);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 61;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(268, 37);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 60;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 37);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 59;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn,
            this.aYLARDataGridViewTextBoxColumn1,
            this.mUTFAKMUSLUGUDataGridViewTextBoxColumn,
            this.ıCMEDataGridViewTextBoxColumn,
            this.mUTFAKDIGERDataGridViewTextBoxColumn,
            this.kISISAYISIDataGridViewTextBoxColumn,
            this.tOPLAMDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.mutfaktalepgunlukBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(10, 146);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1475, 111);
            this.dataGridView1.TabIndex = 85;
            // 
            // ıDDataGridViewTextBoxColumn
            // 
            this.ıDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn.Name = "ıDDataGridViewTextBoxColumn";
            this.ıDDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn1
            // 
            this.aYLARDataGridViewTextBoxColumn1.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn1.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn1.Name = "aYLARDataGridViewTextBoxColumn1";
            this.aYLARDataGridViewTextBoxColumn1.Width = 125;
            // 
            // mUTFAKMUSLUGUDataGridViewTextBoxColumn
            // 
            this.mUTFAKMUSLUGUDataGridViewTextBoxColumn.DataPropertyName = "MUTFAK_MUSLUGU";
            this.mUTFAKMUSLUGUDataGridViewTextBoxColumn.HeaderText = "MUTFAK_MUSLUGU";
            this.mUTFAKMUSLUGUDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mUTFAKMUSLUGUDataGridViewTextBoxColumn.Name = "mUTFAKMUSLUGUDataGridViewTextBoxColumn";
            this.mUTFAKMUSLUGUDataGridViewTextBoxColumn.Width = 125;
            // 
            // ıCMEDataGridViewTextBoxColumn
            // 
            this.ıCMEDataGridViewTextBoxColumn.DataPropertyName = "ICME";
            this.ıCMEDataGridViewTextBoxColumn.HeaderText = "ICME";
            this.ıCMEDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ıCMEDataGridViewTextBoxColumn.Name = "ıCMEDataGridViewTextBoxColumn";
            this.ıCMEDataGridViewTextBoxColumn.Width = 125;
            // 
            // mUTFAKDIGERDataGridViewTextBoxColumn
            // 
            this.mUTFAKDIGERDataGridViewTextBoxColumn.DataPropertyName = "MUTFAK_DIGER";
            this.mUTFAKDIGERDataGridViewTextBoxColumn.HeaderText = "MUTFAK_DIGER";
            this.mUTFAKDIGERDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mUTFAKDIGERDataGridViewTextBoxColumn.Name = "mUTFAKDIGERDataGridViewTextBoxColumn";
            this.mUTFAKDIGERDataGridViewTextBoxColumn.Width = 125;
            // 
            // kISISAYISIDataGridViewTextBoxColumn
            // 
            this.kISISAYISIDataGridViewTextBoxColumn.DataPropertyName = "KISI_SAYISI";
            this.kISISAYISIDataGridViewTextBoxColumn.HeaderText = "KISI_SAYISI";
            this.kISISAYISIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kISISAYISIDataGridViewTextBoxColumn.Name = "kISISAYISIDataGridViewTextBoxColumn";
            this.kISISAYISIDataGridViewTextBoxColumn.Width = 125;
            // 
            // tOPLAMDataGridViewTextBoxColumn
            // 
            this.tOPLAMDataGridViewTextBoxColumn.DataPropertyName = "TOPLAM";
            this.tOPLAMDataGridViewTextBoxColumn.HeaderText = "TOPLAM";
            this.tOPLAMDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tOPLAMDataGridViewTextBoxColumn.Name = "tOPLAMDataGridViewTextBoxColumn";
            this.tOPLAMDataGridViewTextBoxColumn.Width = 125;
            // 
            // mutfaktalepgunlukBindingSource
            // 
            this.mutfaktalepgunlukBindingSource.DataMember = "mutfak_talep_gunluk";
            this.mutfaktalepgunlukBindingSource.DataSource = this.yagmursuyu_databaseDataSet10;
            // 
            // yagmursuyu_databaseDataSet10
            // 
            this.yagmursuyu_databaseDataSet10.DataSetName = "yagmursuyu_databaseDataSet10";
            this.yagmursuyu_databaseDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn1,
            this.aYLARDataGridViewTextBoxColumn,
            this.gUNLERDataGridViewTextBoxColumn,
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn,
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.mutfaktalepaylikBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(10, 330);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(1340, 191);
            this.dataGridView2.TabIndex = 86;
            // 
            // ıDDataGridViewTextBoxColumn1
            // 
            this.ıDDataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn1.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn1.Name = "ıDDataGridViewTextBoxColumn1";
            this.ıDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.ıDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn
            // 
            this.aYLARDataGridViewTextBoxColumn.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn.Name = "aYLARDataGridViewTextBoxColumn";
            this.aYLARDataGridViewTextBoxColumn.Width = 125;
            // 
            // gUNLERDataGridViewTextBoxColumn
            // 
            this.gUNLERDataGridViewTextBoxColumn.DataPropertyName = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn.HeaderText = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gUNLERDataGridViewTextBoxColumn.Name = "gUNLERDataGridViewTextBoxColumn";
            this.gUNLERDataGridViewTextBoxColumn.Width = 125;
            // 
            // mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn
            // 
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn.DataPropertyName = "MUTFAKLARDA_GUNLUK_TOPLAM_TUKETIM";
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn.HeaderText = "MUTFAKLARDA_GUNLUK_TOPLAM_TUKETIM";
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn.Name = "mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn";
            this.mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLIKTALEPMIKTARIDataGridViewTextBoxColumn
            // 
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.DataPropertyName = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.HeaderText = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.Name = "aYLIKTALEPMIKTARIDataGridViewTextBoxColumn";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.Width = 125;
            // 
            // mutfaktalepaylikBindingSource
            // 
            this.mutfaktalepaylikBindingSource.DataMember = "mutfak_talep_aylik";
            this.mutfaktalepaylikBindingSource.DataSource = this.yagmursuyu_databaseDataSet9;
            // 
            // yagmursuyu_databaseDataSet9
            // 
            this.yagmursuyu_databaseDataSet9.DataSetName = "yagmursuyu_databaseDataSet9";
            this.yagmursuyu_databaseDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1492, 204);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 87;
            this.button4.Text = "GERİ";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(700, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 16);
            this.label6.TabIndex = 89;
            this.label6.Text = "TOPLAM";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(692, 37);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 22);
            this.textBox6.TabIndex = 88;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(1492, 175);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 90;
            this.button5.Text = "SİL";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(1492, 146);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 91;
            this.button6.Text = "YENİLE";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Cyan;
            this.label25.Location = new System.Drawing.Point(1291, 11);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(36, 16);
            this.label25.TabIndex = 158;
            this.label25.Text = "NOT";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Cyan;
            this.label22.Location = new System.Drawing.Point(1291, 30);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(323, 16);
            this.label22.TabIndex = 157;
            this.label22.Text = "LÜTFEN TÜM VERİLERİ LİTRE CİNSİNDEN GİRİNİZ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(143, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 16);
            this.label7.TabIndex = 159;
            this.label7.Text = "AYLAR";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(131, 35);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 160;
            // 
            // mutfak_talep_aylikTableAdapter
            // 
            this.mutfak_talep_aylikTableAdapter.ClearBeforeFill = true;
            // 
            // mutfak_talep_gunlukTableAdapter
            // 
            this.mutfak_talep_gunlukTableAdapter.ClearBeforeFill = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 127);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(339, 16);
            this.label20.TabIndex = 161;
            this.label20.Text = "AY BAZINDA ORTALAMA GÜNLÜK TÜKETİM MİKTARI";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(7, 311);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(321, 16);
            this.label21.TabIndex = 162;
            this.label21.Text = "YIL BAZINDA ORTALAMA AYLIK TÜKETİM MİKTARI";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(1787, 655);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Form3";
            this.Text = "MUTFAK_TALEPLER";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mutfaktalepgunlukBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mutfaktalepaylikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox1;
        private yagmursuyu_databaseDataSet9 yagmursuyu_databaseDataSet9;
        private System.Windows.Forms.BindingSource mutfaktalepaylikBindingSource;
        private yagmursuyu_databaseDataSet9TableAdapters.mutfak_talep_aylikTableAdapter mutfak_talep_aylikTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gUNLERDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mUTFAKLARDAGUNLUKTOPLAMTUKETIMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLIKTALEPMIKTARIDataGridViewTextBoxColumn;
        private yagmursuyu_databaseDataSet10 yagmursuyu_databaseDataSet10;
        private System.Windows.Forms.BindingSource mutfaktalepgunlukBindingSource;
        private yagmursuyu_databaseDataSet10TableAdapters.mutfak_talep_gunlukTableAdapter mutfak_talep_gunlukTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn mUTFAKMUSLUGUDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıCMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mUTFAKDIGERDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kISISAYISIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tOPLAMDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
    }
}