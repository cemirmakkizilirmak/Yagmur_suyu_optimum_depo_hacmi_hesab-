﻿namespace sqldenemem
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dUSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lAVABODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tUVALETDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cAMASIRMAKINESIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kUVETDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dISYIKAMADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cAMASIRMUSLUGUDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bANYODIGERDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kISISAYISIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tOPLAMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tuvalettalepgunlukBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.yagmursuyu_databaseDataSet12 = new sqldenemem.yagmursuyu_databaseDataSet12();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLARDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gUNLERDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tuvalettalepaylikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tuvalet_talep_gunlukTableAdapter = new sqldenemem.yagmursuyu_databaseDataSet12TableAdapters.tuvalet_talep_gunlukTableAdapter();
            this.tuvalet_talep_aylikTableAdapter = new sqldenemem.yagmursuyu_databaseDataSet12TableAdapters.tuvalet_talep_aylikTableAdapter();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tuvalettalepgunlukBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tuvalettalepaylikBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(23, 41);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "VERI GIR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(273, 35);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(379, 35);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(485, 35);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 5;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(591, 35);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 22);
            this.textBox5.TabIndex = 6;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(697, 35);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 22);
            this.textBox6.TabIndex = 7;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(803, 35);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 22);
            this.textBox7.TabIndex = 8;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(909, 35);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 22);
            this.textBox8.TabIndex = 9;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(1015, 35);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 22);
            this.textBox9.TabIndex = 10;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(1121, 35);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 22);
            this.textBox10.TabIndex = 11;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(1227, 35);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 22);
            this.textBox11.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(270, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "DUS";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(376, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "LAVABO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(482, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 16);
            this.label4.TabIndex = 16;
            this.label4.Text = "TUVALET";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(588, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 16);
            this.label5.TabIndex = 17;
            this.label5.Text = "CAM_MAK";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(694, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 16);
            this.label6.TabIndex = 18;
            this.label6.Text = "KUVET";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(800, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 16);
            this.label7.TabIndex = 19;
            this.label7.Text = "DIS_YIK";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(906, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 16);
            this.label8.TabIndex = 20;
            this.label8.Text = "CAM_MUS";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1012, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 16);
            this.label9.TabIndex = 21;
            this.label9.Text = "BANYO_DIG";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1118, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 16);
            this.label10.TabIndex = 22;
            this.label10.Text = "KISI_SAY";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1224, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 16);
            this.label11.TabIndex = 23;
            this.label11.Text = "TOPLAM";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(25, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 23);
            this.button2.TabIndex = 24;
            this.button2.Text = "TOPLA";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn,
            this.aYLARDataGridViewTextBoxColumn,
            this.dUSDataGridViewTextBoxColumn,
            this.lAVABODataGridViewTextBoxColumn,
            this.tUVALETDataGridViewTextBoxColumn,
            this.cAMASIRMAKINESIDataGridViewTextBoxColumn,
            this.kUVETDataGridViewTextBoxColumn,
            this.dISYIKAMADataGridViewTextBoxColumn,
            this.cAMASIRMUSLUGUDataGridViewTextBoxColumn,
            this.bANYODIGERDataGridViewTextBoxColumn,
            this.kISISAYISIDataGridViewTextBoxColumn,
            this.tOPLAMDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tuvalettalepgunlukBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 160);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1475, 223);
            this.dataGridView1.TabIndex = 25;
            // 
            // ıDDataGridViewTextBoxColumn
            // 
            this.ıDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn.Name = "ıDDataGridViewTextBoxColumn";
            this.ıDDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn
            // 
            this.aYLARDataGridViewTextBoxColumn.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn.Name = "aYLARDataGridViewTextBoxColumn";
            this.aYLARDataGridViewTextBoxColumn.Width = 125;
            // 
            // dUSDataGridViewTextBoxColumn
            // 
            this.dUSDataGridViewTextBoxColumn.DataPropertyName = "DUS";
            this.dUSDataGridViewTextBoxColumn.HeaderText = "DUS";
            this.dUSDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dUSDataGridViewTextBoxColumn.Name = "dUSDataGridViewTextBoxColumn";
            this.dUSDataGridViewTextBoxColumn.Width = 125;
            // 
            // lAVABODataGridViewTextBoxColumn
            // 
            this.lAVABODataGridViewTextBoxColumn.DataPropertyName = "LAVABO";
            this.lAVABODataGridViewTextBoxColumn.HeaderText = "LAVABO";
            this.lAVABODataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lAVABODataGridViewTextBoxColumn.Name = "lAVABODataGridViewTextBoxColumn";
            this.lAVABODataGridViewTextBoxColumn.Width = 125;
            // 
            // tUVALETDataGridViewTextBoxColumn
            // 
            this.tUVALETDataGridViewTextBoxColumn.DataPropertyName = "TUVALET";
            this.tUVALETDataGridViewTextBoxColumn.HeaderText = "TUVALET";
            this.tUVALETDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tUVALETDataGridViewTextBoxColumn.Name = "tUVALETDataGridViewTextBoxColumn";
            this.tUVALETDataGridViewTextBoxColumn.Width = 125;
            // 
            // cAMASIRMAKINESIDataGridViewTextBoxColumn
            // 
            this.cAMASIRMAKINESIDataGridViewTextBoxColumn.DataPropertyName = "CAMASIR_MAKINESI";
            this.cAMASIRMAKINESIDataGridViewTextBoxColumn.HeaderText = "CAMASIR_MAKINESI";
            this.cAMASIRMAKINESIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cAMASIRMAKINESIDataGridViewTextBoxColumn.Name = "cAMASIRMAKINESIDataGridViewTextBoxColumn";
            this.cAMASIRMAKINESIDataGridViewTextBoxColumn.Width = 125;
            // 
            // kUVETDataGridViewTextBoxColumn
            // 
            this.kUVETDataGridViewTextBoxColumn.DataPropertyName = "KUVET";
            this.kUVETDataGridViewTextBoxColumn.HeaderText = "KUVET";
            this.kUVETDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kUVETDataGridViewTextBoxColumn.Name = "kUVETDataGridViewTextBoxColumn";
            this.kUVETDataGridViewTextBoxColumn.Width = 125;
            // 
            // dISYIKAMADataGridViewTextBoxColumn
            // 
            this.dISYIKAMADataGridViewTextBoxColumn.DataPropertyName = "DIS_YIKAMA";
            this.dISYIKAMADataGridViewTextBoxColumn.HeaderText = "DIS_YIKAMA";
            this.dISYIKAMADataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dISYIKAMADataGridViewTextBoxColumn.Name = "dISYIKAMADataGridViewTextBoxColumn";
            this.dISYIKAMADataGridViewTextBoxColumn.Width = 125;
            // 
            // cAMASIRMUSLUGUDataGridViewTextBoxColumn
            // 
            this.cAMASIRMUSLUGUDataGridViewTextBoxColumn.DataPropertyName = "CAMASIR_MUSLUGU";
            this.cAMASIRMUSLUGUDataGridViewTextBoxColumn.HeaderText = "CAMASIR_MUSLUGU";
            this.cAMASIRMUSLUGUDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cAMASIRMUSLUGUDataGridViewTextBoxColumn.Name = "cAMASIRMUSLUGUDataGridViewTextBoxColumn";
            this.cAMASIRMUSLUGUDataGridViewTextBoxColumn.Width = 125;
            // 
            // bANYODIGERDataGridViewTextBoxColumn
            // 
            this.bANYODIGERDataGridViewTextBoxColumn.DataPropertyName = "BANYO_DIGER";
            this.bANYODIGERDataGridViewTextBoxColumn.HeaderText = "BANYO_DIGER";
            this.bANYODIGERDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.bANYODIGERDataGridViewTextBoxColumn.Name = "bANYODIGERDataGridViewTextBoxColumn";
            this.bANYODIGERDataGridViewTextBoxColumn.Width = 125;
            // 
            // kISISAYISIDataGridViewTextBoxColumn
            // 
            this.kISISAYISIDataGridViewTextBoxColumn.DataPropertyName = "KISI_SAYISI";
            this.kISISAYISIDataGridViewTextBoxColumn.HeaderText = "KISI_SAYISI";
            this.kISISAYISIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kISISAYISIDataGridViewTextBoxColumn.Name = "kISISAYISIDataGridViewTextBoxColumn";
            this.kISISAYISIDataGridViewTextBoxColumn.Width = 125;
            // 
            // tOPLAMDataGridViewTextBoxColumn
            // 
            this.tOPLAMDataGridViewTextBoxColumn.DataPropertyName = "TOPLAM";
            this.tOPLAMDataGridViewTextBoxColumn.HeaderText = "TOPLAM";
            this.tOPLAMDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tOPLAMDataGridViewTextBoxColumn.Name = "tOPLAMDataGridViewTextBoxColumn";
            this.tOPLAMDataGridViewTextBoxColumn.Width = 125;
            // 
            // tuvalettalepgunlukBindingSource
            // 
            this.tuvalettalepgunlukBindingSource.DataMember = "tuvalet_talep_gunluk";
            this.tuvalettalepgunlukBindingSource.DataSource = this.yagmursuyu_databaseDataSet12;
            // 
            // yagmursuyu_databaseDataSet12
            // 
            this.yagmursuyu_databaseDataSet12.DataSetName = "yagmursuyu_databaseDataSet12";
            this.yagmursuyu_databaseDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn1,
            this.aYLARDataGridViewTextBoxColumn1,
            this.gUNLERDataGridViewTextBoxColumn,
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn,
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.tuvalettalepaylikBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(12, 450);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(1119, 191);
            this.dataGridView2.TabIndex = 50;
            // 
            // ıDDataGridViewTextBoxColumn1
            // 
            this.ıDDataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn1.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.ıDDataGridViewTextBoxColumn1.Name = "ıDDataGridViewTextBoxColumn1";
            this.ıDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.ıDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // aYLARDataGridViewTextBoxColumn1
            // 
            this.aYLARDataGridViewTextBoxColumn1.DataPropertyName = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn1.HeaderText = "AYLAR";
            this.aYLARDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.aYLARDataGridViewTextBoxColumn1.Name = "aYLARDataGridViewTextBoxColumn1";
            this.aYLARDataGridViewTextBoxColumn1.Width = 125;
            // 
            // gUNLERDataGridViewTextBoxColumn
            // 
            this.gUNLERDataGridViewTextBoxColumn.DataPropertyName = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn.HeaderText = "GUNLER";
            this.gUNLERDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gUNLERDataGridViewTextBoxColumn.Name = "gUNLERDataGridViewTextBoxColumn";
            this.gUNLERDataGridViewTextBoxColumn.Width = 125;
            // 
            // tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn
            // 
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn.DataPropertyName = "TUVALETLER_ICIN_GUNLUK_TOPLAM_TUKETIM_MIKTARI";
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn.HeaderText = "TUVALETLER_ICIN_GUNLUK_TOPLAM_TUKETIM_MIKTARI";
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn.Name = "tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn";
            this.tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn.Width = 125;
            // 
            // aYLIKTALEPMIKTARIDataGridViewTextBoxColumn
            // 
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.DataPropertyName = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.HeaderText = "AYLIK_TALEP_MIKTARI";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.Name = "aYLIKTALEPMIKTARIDataGridViewTextBoxColumn";
            this.aYLIKTALEPMIKTARIDataGridViewTextBoxColumn.Width = 125;
            // 
            // tuvalettalepaylikBindingSource
            // 
            this.tuvalettalepaylikBindingSource.DataMember = "tuvalet_talep_aylik";
            this.tuvalettalepaylikBindingSource.DataSource = this.yagmursuyu_databaseDataSet12;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(25, 70);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 22);
            this.textBox24.TabIndex = 52;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(131, 70);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(194, 16);
            this.label12.TabIndex = 53;
            this.label12.Text = "ŞUBAT GÜN SAYISINI GİRİNİZ";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.textBox24);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Location = new System.Drawing.Point(1420, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(329, 101);
            this.panel1.TabIndex = 55;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(139, 41);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(14, 16);
            this.label18.TabIndex = 64;
            this.label18.Text = "5";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(164, 41);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(90, 23);
            this.button5.TabIndex = 63;
            this.button5.Text = "TEMİZLE";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(139, 15);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 16);
            this.label17.TabIndex = 62;
            this.label17.Text = "4";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 73);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 16);
            this.label16.TabIndex = 61;
            this.label16.Text = "3";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 44);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 16);
            this.label15.TabIndex = 60;
            this.label15.Text = "2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 16);
            this.label14.TabIndex = 59;
            this.label14.Text = "1";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(164, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 23);
            this.button3.TabIndex = 57;
            this.button3.Text = "AKTAR";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 71);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(144, 16);
            this.label13.TabIndex = 58;
            this.label13.Text = "Lütfen litre olarak giriniz";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(1493, 177);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 63;
            this.button7.Text = "YENİLE";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(1493, 206);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 62;
            this.button8.Text = "SİL";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Gainsboro;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.Location = new System.Drawing.Point(1493, 235);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 59;
            this.button4.Text = "GERİ";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(10, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 64;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 16);
            this.label1.TabIndex = 65;
            this.label1.Text = "ID";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Cyan;
            this.label25.Location = new System.Drawing.Point(1417, 118);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(36, 16);
            this.label25.TabIndex = 156;
            this.label25.Text = "NOT";
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Cyan;
            this.label22.Location = new System.Drawing.Point(1417, 137);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(323, 16);
            this.label22.TabIndex = 155;
            this.label22.Text = "LÜTFEN TÜM VERİLERİ LİTRE CİNSİNDEN GİRİNİZ";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(132, 33);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 157;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(138, 9);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(51, 16);
            this.label19.TabIndex = 158;
            this.label19.Text = "AYLAR";
            // 
            // tuvalet_talep_gunlukTableAdapter
            // 
            this.tuvalet_talep_gunlukTableAdapter.ClearBeforeFill = true;
            // 
            // tuvalet_talep_aylikTableAdapter
            // 
            this.tuvalet_talep_aylikTableAdapter.ClearBeforeFill = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 137);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(339, 16);
            this.label20.TabIndex = 159;
            this.label20.Text = "AY BAZINDA ORTALAMA GÜNLÜK TÜKETİM MİKTARI";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 431);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(321, 16);
            this.label21.TabIndex = 160;
            this.label21.Text = "YIL BAZINDA ORTALAMA AYLIK TÜKETİM MİKTARI";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(1776, 715);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Name = "Form1";
            this.Text = "TUVALET_BANYO_TALEPLER";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tuvalettalepgunlukBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yagmursuyu_databaseDataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tuvalettalepaylikBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label19;
        private yagmursuyu_databaseDataSet12 yagmursuyu_databaseDataSet12;
        private System.Windows.Forms.BindingSource tuvalettalepgunlukBindingSource;
        private yagmursuyu_databaseDataSet12TableAdapters.tuvalet_talep_gunlukTableAdapter tuvalet_talep_gunlukTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dUSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lAVABODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tUVALETDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cAMASIRMAKINESIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kUVETDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dISYIKAMADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cAMASIRMUSLUGUDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bANYODIGERDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kISISAYISIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tOPLAMDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource tuvalettalepaylikBindingSource;
        private yagmursuyu_databaseDataSet12TableAdapters.tuvalet_talep_aylikTableAdapter tuvalet_talep_aylikTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLARDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn gUNLERDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tUVALETLERICINGUNLUKTOPLAMTUKETIMMIKTARIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aYLIKTALEPMIKTARIDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
    }
}

