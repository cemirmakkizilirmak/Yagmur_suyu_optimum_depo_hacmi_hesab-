﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Windows.Forms.DataVisualization.Charting;
using System.IO.Ports;
using System.IO;

namespace sqldenemem
{
    public partial class Form6 : Form
    {
        private ToolTip toolTip1 = new ToolTip();

        public Form6()
        {
            InitializeComponent();

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            chart2.GetToolTipText += Chart2_GetToolTipText;
        }

        private void button1_Click(object sender, EventArgs e)
        {

                this.tuvalet_talep_aylikTableAdapter.Fill(this.yagmursuyu_databaseDataSet2.tuvalet_talep_aylik);
                dataGridView1.DataSource = this.yagmursuyu_databaseDataSet2.tuvalet_talep_aylik;


        }

        private void button2_Click(object sender, EventArgs e)
        {
       

            this.mutfak_talep_aylikTableAdapter.Fill(this.ben.mutfak_talep_aylik);
            dataGridView2.DataSource = this.ben.mutfak_talep_aylik;

        }

        private void button3_Click(object sender, EventArgs e)
        {
         

            this.diger_talep_aylikTableAdapter.Fill(this.yagmursuyu_databaseDataSet.diger_talep_aylik);
            dataGridView3.DataSource = this.yagmursuyu_databaseDataSet.diger_talep_aylik;

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.arzTableAdapter1.Fill(this.yagmursuyu_databaseDataSet13.arz);
            dataGridView4.DataSource = this.yagmursuyu_databaseDataSet13.arz;

        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.peyjaz_talep_aylikTableAdapter.Fill(this.yagmursuyu_databaseDataSet6.peyjaz_talep_aylik);
            dataGridView5.DataSource = this.yagmursuyu_databaseDataSet6.peyjaz_talep_aylik;
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            TextBox[] textBoxes = { textBox1, textBox2, textBox3, textBox4, textBox5, textBox6,
                        textBox7, textBox8, textBox9, textBox10, textBox11, textBox12 };

            int maxRows = Math.Min(12, dataGridView1.Rows.Count); // Eğer satır sayısı 12'den azsa ona göre sınırla

            for (int i = 0; i < maxRows; i++)
            {
                if (dataGridView1.Rows[i].Cells.Count > 4) // 4. sütun var mı kontrol et
                {
                    object value = dataGridView1.Rows[i].Cells[4].Value;
                    if (value != null && int.TryParse(value.ToString(), out int intValue))
                    {
                        textBoxes[i].Text = intValue.ToString(); // Başarılıysa integer olarak yaz
                    }
                    else
                    {
                        textBoxes[i].Text = "0"; // Başarısızsa 0 yaz
                    }
                }
            }



        }

        private void dataGridView3_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            // TextBox'ları liste olarak al (Form üzerindeki TextBox'lar)
            TextBox[] textBoxes = { textBox36, textBox35, textBox34, textBox33, textBox32, textBox31,
                        textBox30, textBox29, textBox28, textBox27, textBox26, textBox25 };

            // İlk 12 satırın 5. sütunundaki değerleri TextBox'lara ata (index 4)
            int maxRows = Math.Min(12, dataGridView3.Rows.Count); // Eğer satır sayısı 12'den azsa ona göre sınırla

            for (int i = 0; i < maxRows; i++)
            {
                if (dataGridView3.Rows[i].Cells.Count > 4) // 5. sütun var mı kontrol et
                {
                    object value = dataGridView3.Rows[i].Cells[4].Value;

                    if (value != null && int.TryParse(value.ToString(), out int intValue))
                    {
                        textBoxes[i].Text = intValue.ToString(); // int olarak yaz
                    }
                    else
                    {
                        textBoxes[i].Text = "0"; // geçersizse 0 yaz
                    }
                }
            }

        }

        private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            TextBox[] textBoxes = { textBox24, textBox23, textBox22, textBox21, textBox20, textBox19,
                        textBox18, textBox17, textBox16, textBox15, textBox14, textBox13 };

            int maxRows = Math.Min(12, dataGridView2.Rows.Count); // Eğer satır sayısı 12'den azsa sınırla

            for (int i = 0; i < maxRows; i++)
            {
                if (dataGridView2.Rows[i].Cells.Count > 4) // 5. sütun mevcut mu kontrol et
                {
                    object value = dataGridView2.Rows[i].Cells[4].Value;

                    if (value != null && int.TryParse(value.ToString(), out int intValue))
                    {
                        textBoxes[i].Text = intValue.ToString(); // integer olarak ata
                    }
                    else
                    {
                        textBoxes[i].Text = "0"; // geçersizse 0 ata
                    }
                }
            }

        }

        private void TOP(object sender, EventArgs e)
        {
          
                // Toplamalar
                TextBox[] textBoxes1 = { textBox1, textBox2, textBox3, textBox4, textBox5, textBox6,
                             textBox7, textBox8, textBox9, textBox10, textBox11, textBox12 };

                TextBox[] textBoxes2 = { textBox24, textBox23, textBox22, textBox21, textBox20, textBox19,
                             textBox18, textBox17, textBox16, textBox15, textBox14, textBox13 };

                TextBox[] textBoxes3 = { textBox36, textBox35, textBox34, textBox33, textBox32, textBox31,
                             textBox30, textBox29, textBox28, textBox27, textBox26, textBox25 };

                TextBox[] textBoxes4 = { textBox72, textBox71, textBox70, textBox69, textBox68, textBox67,
                        textBox66, textBox65, textBox64, textBox63, textBox62, textBox61 };


            // Sonuçları yazacağımız TextBox dizisi
            TextBox[] resultTextBoxes = { textBox48, textBox47, textBox46, textBox45, textBox44, textBox43,
                                  textBox42, textBox41, textBox40, textBox39, textBox38, textBox37 };


              

            // Hesaplamaları yap ve ilgili TextBox'a yaz
            for (int i = 0; i < 12; i++) 
                {
                    // Null veya boş olup olmadığını kontrol et, boşsa 0 olarak kabul et
                    double value1 = double.TryParse(textBoxes1[i].Text, out double v1) ? v1 : 0;
                    double value2 = double.TryParse(textBoxes2[i].Text, out double v2) ? v2 : 0;
                    double value3 = double.TryParse(textBoxes3[i].Text, out double v3) ? v3 : 0;
                    double value4 = double.TryParse(textBoxes4[i].Text, out double v4) ? v4 : 0;

                // Toplamı ilgili sonucu tutacak TextBox'a yaz
                resultTextBoxes[i].Text = (value1 + value2 + value3 +value4).ToString();
                }
            

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show(); // Form1'i aç
            this.Hide(); // Form2'yi kapat
        }


        private void dataGridView4_DoubleClick(object sender, EventArgs e)
        {
            // TextBox'ları liste olarak al (Form üzerindeki TextBox'lar)
            TextBox[] textBoxes = { textBox60, textBox59, textBox58, textBox57, textBox56, textBox55,
                        textBox54, textBox53, textBox52, textBox51, textBox50, textBox49 };

           
            int maxRows = Math.Min(12, dataGridView4.Rows.Count); // Eğer satır sayısı 12'den azsa ona göre sınırla

            for (int i = 0; i < maxRows; i++)
            {
                if (dataGridView4.Rows[i].Cells.Count > 5) // 4. sütun (index 6) var mı kontrol et
                {
                    object value = dataGridView4.Rows[i].Cells[5].Value;
                    if (value != null && double.TryParse(value.ToString(), out double number))
                    {
                        textBoxes[i].Text = Convert.ToInt32(number).ToString(); // Double'dan int'e dönüştür ve yaz
                    }
                    else
                    {
                        textBoxes[i].Text = "";
                    }
                }
            }

        }

        private void chart1_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                Chart chart = sender as Chart;
                var pos = e.Location;
                var results = chart.HitTest(pos.X, pos.Y, false, ChartElementType.DataPoint);

                foreach (var result in results)
                {
                    if (result.ChartElementType == ChartElementType.DataPoint)
                    {
                        var point = result.Series.Points[result.PointIndex];

                        double xValue = point.XValue;
                        double yValue = point.YValues[0];

                        // X ve Y değerlerini göster
                        toolTip1.Show("X: " + xValue + ", Y: " + yValue, chart, e.X, e.Y);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void dataGridView5_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            TextBox[] textBoxes = { textBox72, textBox71, textBox70, textBox69, textBox68, textBox67,
                        textBox66, textBox65, textBox64, textBox63, textBox62, textBox61 };


            // İlk 12 satırın 4. sütunundaki değerleri TextBox'lara ata
            int maxRows = Math.Min(12, dataGridView5.Rows.Count); // Eğer satır sayısı 12'den azsa ona göre sınırla

            for (int i = 0; i < maxRows; i++)
            {
                if (dataGridView5.Rows[i].Cells.Count > 5) // 4. sütun var mı kontrol et
                {
                    object value = dataGridView5.Rows[i].Cells[5].Value; // 4. sütun (index 3)
                    textBoxes[i].Text = value?.ToString() ?? ""; // Null kontrolü yaparak TextBox'a ata
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {

            try
            {

                for (int i = 0; i <= 11; i++) 
                {
                    double deger1 = double.Parse(Controls["textBox" + (60 - i)].Text);
                    double deger2 = double.Parse(Controls["textBox" + (48 - i)].Text);
                    double fark = deger1 - deger2; // Farkı hesapla

                    Controls["textBox" + (84 - i)].Text = fark.ToString(); // Sonucu ilgili textbox’a yaz

                }
            }

            catch {

                MessageBox.Show("Lütfen Arz veyahut Talep verilerini giriniz");
            }

        }

        private void button10_Click(object sender, EventArgs e)
        {

            
                // Başlangıçta gerekli textbox'lardan değerleri al (boşsa 0 kabul et)
                int value84 = int.TryParse(textBox84.Text, out int v84) ? v84 : 0;
                int value96 = int.TryParse(textBox96.Text, out int v96) ? v96 : 0;
                int value110 = int.TryParse(textBox110.Text, out int v110) ? v110 : 0;
                int value111 = int.TryParse(textBox111.Text, out int v111) ? v111 : 0;

                // İlk toplam işlemi (textBox84 + textBox111)
                int toplam = value84 + value111;

                if (toplam > value110)
                {
                    textBox108.Text = (toplam - value110).ToString(); // Artan kısmı yaz
                    textBox96.Text = value110.ToString();             // Max sınırı yaz
                }
                else
                {
                    textBox108.Text = "0";                            // Artan yoksa sıfır
                    textBox96.Text = toplam.ToString();               // Toplamı yaz
                }

                //11 adet kontrol (83–73) ve (96–86) arası
                for (int i = 0; i < 11; i++)
                {
                    // Her döngü adımında textBox110'un güncel değeri al
                    int valueZ = int.TryParse(textBox110.Text, out int vZ) ? vZ : 0;

                    // textBox83'ten geriye ve textBox96'dan geriye sırayla al
                    int valueX = int.TryParse(this.Controls["textBox" + (83 - i)].Text, out int vX) ? vX : 0;
                    int valueY = int.TryParse(this.Controls["textBox" + (96 - i)].Text, out int vY) ? vY : 0;

                    // İki değeri topla
                    toplam = valueX + valueY;

                    // Karşılaştır ve değerleri yerleştir
                    if (toplam > valueZ)
                    {
                        // Artanı 107'den geri giden textBox'a yaz
                        this.Controls["textBox" + (107 - i)].Text = (toplam - valueZ).ToString();
                        // Sınır değerini 95'ten geri giden textBox'a yaz
                        this.Controls["textBox" + (95 - i)].Text = valueZ.ToString();
                    }
                    else
                    {
                        // Artan yoksa sıfır yaz
                        this.Controls["textBox" + (107 - i)].Text = "0";
                        // Toplamı sınırın altındaysa doğrudan yaz
                        this.Controls["textBox" + (95 - i)].Text = toplam.ToString();
                    }
                
            }



        }

        private void Chart2_GetToolTipText(object sender, ToolTipEventArgs e)
        {
            if (e.HitTestResult.ChartElementType == ChartElementType.DataPoint)
            {
                var point = e.HitTestResult.Series.Points[e.HitTestResult.PointIndex];
                var xValue = point.XValue;
                var yValue = point.YValues[0];
                var seriesName = e.HitTestResult.Series.Name;

                e.Text = $"Seri: {seriesName}\nX (Ay): {xValue}\nY (Litre): {yValue}";
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
          //   Önce Series1, Series2, Series3 ve Series4'ü temizle
            chart2.Series["TOPLAM_TALEP"].Points.Clear();
            chart2.Series["TOPLAM_ARZ"].Points.Clear();
            chart2.Series["ARZ/TALEP_FARKI"].Points.Clear();
            chart2.Series["TANKIN_İÇİNDEKİ_SU_HACMİ"].Points.Clear();

            // X ekseni için ay isimleri
            string[] aylar = { "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
            "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık" };

            // X ekseni 1'den 12'ye kadar gider
            for (int i = 0; i < 12; i++)
            {
                // Y ekseni için textbox48 den textbox37 ye kadar olan değerleri al
                int yValue1 = int.TryParse(this.Controls["textBox" + (48 - i)].Text, out int y1) ? y1 : 0;

                // Grafiğe TOPLAM_TALEP e noktayı ekle
                chart2.Series["TOPLAM_TALEP"].Points.AddXY(i + 1, yValue1);

                // Y ekseni için textbox60 den textbox49 a kadar olan değerleri al
                int yValue2 = int.TryParse(this.Controls["textBox" + (60 - i)].Text, out int y2) ? y2 : 0;

                // Grafiğe TOPLAM_ARZ a noktayı ekle
                chart2.Series["TOPLAM_ARZ"].Points.AddXY(i + 1, yValue2);

                // Y ekseni için textbox84 ten textbox73 e kadar olan değerleri al
                int yValue3 = int.TryParse(this.Controls["textBox" + (84 - i)].Text, out int y3) ? y3 : 0;

                // Grafiğe ARZ/TALEP_FARKI na noktayı ekle
                chart2.Series["ARZ/TALEP_FARKI"].Points.AddXY(i + 1, yValue3);

                // Y ekseni için textbox96 dan textbox85 e kadar olan değerleri al
                int yValue4 = int.TryParse(this.Controls["textBox" + (96 - i)].Text, out int y4) ? y4 : 0;

                // Grafiğe TANKIN_İÇİNDEKİ_SU_HACMİ ne noktayı ekle
                chart2.Series["TANKIN_İÇİNDEKİ_SU_HACMİ"].Points.AddXY(i + 1, yValue4);
            }

            // X ekseni etiketlerini ay isimleriyle değiştir
            chart2.ChartAreas[0].AxisX.CustomLabels.Clear();
            for (int i = 0; i < 12; i++)
            {
                chart2.ChartAreas[0].AxisX.CustomLabels.Add(i + 0.5, i + 1.5, aylar[i]);
            }

            // X ekseni sınırlarını belirle (1-12 arası)
            chart2.ChartAreas[0].AxisX.Minimum = 1;
            chart2.ChartAreas[0].AxisX.Maximum = 12;
            chart2.ChartAreas[0].AxisX.Interval = 1;

            // Y ekseni başlığı (Litre olarak ayarla)
            chart2.ChartAreas[0].AxisY.Title = "Litre";
            chart2.ChartAreas[0].AxisY.TitleFont = new Font("Arial", 12, FontStyle.Bold);

            // Y eksenini görünür kıl
            chart2.ChartAreas[0].AxisY.IsStartedFromZero = true;

            // Series'leri aynı grafikte eş zamanlı olarak göster
            chart2.Series["TOPLAM_TALEP"].ChartType = SeriesChartType.Line;   
            chart2.Series["TOPLAM_ARZ"].ChartType = SeriesChartType.Line;   
            chart2.Series["ARZ/TALEP_FARKI"].ChartType = SeriesChartType.Line;   
            chart2.Series["TANKIN_İÇİNDEKİ_SU_HACMİ"].ChartType = SeriesChartType.Line;   

            // Series'lerin ToolTip ini ayarla
             chart2.Series["TOPLAM_TALEP"].ToolTip = "Ay: #VALX\nDeğer: #VALY";
             chart2.Series["TOPLAM_ARZ"].ToolTip = "Ay: #VALX\nDeğer: #VALY";
             chart2.Series["ARZ/TALEP_FARKI"].ToolTip = "Ay: #VALX\nDeğer: #VALY";
             chart2.Series["TANKIN_İÇİNDEKİ_SU_HACMİ"].ToolTip = "Ay: #VALX\nDeğer: #VALY";


        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

       

        private void label28_Click(object sender, EventArgs e)
        {

        }

       
    }
}
