﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sqldenemem
{
    public partial class Form8 : Form
    {
        private ToolTip toolTip1 = new ToolTip(); // ToolTip nesnesini manuel oluştur.

        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            this.arzTableAdapter1.Fill(this.yagmursuyu_databaseDataSet13.arz);
            this.chart1.MouseMove += chart1_MouseMove;


    }

    private void button7_Click(object sender, EventArgs e)
        {
            string[] aylar = {
    "ARALIK", "KASIM", "EKİM", "EYLÜL", "AĞUSTOS", "TEMMUZ",
    "HAZİRAN", "MAYIS", "NİSAN", "MART", "ŞUBAT", "OCAK"
                                };
            chart1.ChartAreas[0].AxisX.Title = "HASAT ALANI (m²)";
            chart1.ChartAreas[0].AxisY.Title = "YAĞIŞ MİKTARI (m³)";

            for (int i = 49; i <= 60; i++) // TextBox49'dan TextBox60'a kadar
            {
                TextBox ctrlX = this.Controls["textBox" + i] as TextBox; // TextBox'ı al

                if (ctrlX != null) // Eğer textBox varsa
                {
                    double valueX;
                    if (double.TryParse(ctrlX.Text, out valueX)) // İçindeki değeri al ve double'a çevir
                    {
                        string seriesName = aylar[i - 49]; // TextBox49 için "OCAK", TextBox50 için "ŞUBAT", ...

                        if (!chart1.Series.IsUniqueName(seriesName))
                        {
                            chart1.Series.Remove(chart1.Series[seriesName]); // Aynı isimde varsa önce kaldır
                        }

                        chart1.Series.Add(seriesName); // Yeni seri ekle
                        chart1.Series[seriesName].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line; // Çizgi grafik

                        int xValue = 50; // X ekseni başlangıç değeri

                        while (xValue <= 1200) // X ekseni 50 adımda artarak 1200'e kadar gidecek
                        {
                            double yValue = valueX * xValue / 1000; // Y ekseni = TextBox içindeki değer * X ekseni değeri
                            chart1.Series[seriesName].Points.AddXY(xValue, yValue); // Grafiğe ekle

                            xValue += 50; // X eksenini 50 artır
                        }
                    }
                }
            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            // TextBox'ları liste olarak al (Form üzerindeki TextBox'lar)
            TextBox[] textBoxes = { textBox60, textBox59, textBox58, textBox57, textBox56, textBox55,
                        textBox54, textBox53, textBox52, textBox51, textBox50, textBox49 };

            // İlk 12 satırın 4. sütunundaki değerleri TextBox'lara ata
            int maxRows = Math.Min(12, dataGridView1.Rows.Count); // Eğer satır sayısı 12'den azsa ona göre sınırla

            for (int i = 0; i < maxRows; i++)
            {
                if (dataGridView1.Rows[i].Cells.Count > 2) // 4. sütun var mı kontrol et
                {
                    object value = dataGridView1.Rows[i].Cells[2].Value; // 4. sütun (index 3)
                    textBoxes[i].Text = value?.ToString() ?? ""; // Null kontrolü yaparak TextBox'a ata
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show(); // Form1'i aç
            this.Hide(); // Form2'yi kapat
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
        private void chart1_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                var chartArea = chart1.ChartAreas[0];
                double mouseX = chartArea.AxisX.PixelPositionToValue(e.X);
                int roundedX = (int)(Math.Round(mouseX / 50.0) * 50);

                if (roundedX < 50 || roundedX > 1200)
                {
                    toolTip1.Hide(chart1);
                    return;
                }

                double toplamY = 0;

                foreach (var series in chart1.Series)
                {
                    foreach (var point in series.Points)
                    {
                        if (Math.Abs(point.XValue - roundedX) < 0.001)
                        {
                            toplamY += point.YValues[0];
                            break;
                        }
                    }
                }

                toolTip1.Show($"Hasat_Alani = {roundedX} m²\nToplam_Yagis_Miktari = {toplamY:F2} m³", chart1, e.X + 15, e.Y - 20);
            }
            catch
            {
                toolTip1.Hide(chart1);
            }


            }
            
        private void chart1_MouseLeave(object sender, EventArgs e)
        {
            toolTip1.Hide(chart1);
        }

    }
}
